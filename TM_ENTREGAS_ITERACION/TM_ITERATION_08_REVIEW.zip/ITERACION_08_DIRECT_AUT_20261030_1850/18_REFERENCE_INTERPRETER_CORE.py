"""TM REFERENCE INTERPRETER V1 — core only.

Scope (deliberately limited):
  * reading ownership
  * function 1
  * opening evaluation
  * 2 candidate / confirmed / impossible
  * module by discard (1+2)
  * 3 pending / confirmed / impossible
  * module 1+2+3
  * 3 live extreme

NOT implemented:
  A, B, C, AUT, CUT, TT, FT, gap new-1, concurrency.
Those are blocked by scope, not assumed.

The interpreter is deterministic and has no future information: every
transition is evaluated from the current tick and the state built so far.
"""
from __future__ import annotations

import argparse
import csv
import json
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
FEED = ROOT / "TM_CANON_ACTIVO" / "02_TICKS" / "TM_TICKFEED_1615_1730.csv"

PLANO = 25       # 0.25 in cents
NOISE = 200      # 2.00 points: physical noise filter
CORE_VERSION = "TM_REFERENCE_INTERPRETER_V1_CORE"


@dataclass
class Tick:
    seq: int
    time_ms: int
    bar: int
    price: int


@dataclass
class Reading:
    reading_id: str
    gid: int = 1
    parent: int = 0
    phase: str = "INITIAL_BAR"

    one_dir: int = 0
    one_origin: int = 0
    one_extreme: int = 0
    one_extreme_st: int = 0
    one_size: int = 0
    one_st: int = 0
    one_kt: int = 0
    one_bar: int = -1
    one_status: str = ""

    two_origin: int = 0
    two_extreme: int = 0
    two_extreme_st: int = 0
    two_dir: int = 0
    two_size: int = 0
    two_st: int = 0
    two_bar: int = -1
    two_kt: int = 0
    two_status: str = ""
    two_tail: int = 0
    two_seen_dir: bool = False

    three_extreme: int = 0
    three_extreme_st: int = 0
    three_st: int = 0
    three_kt: int = 0
    three_status: str = ""
    retr_active: bool = False
    retr_extreme: int = 0
    retr_base_size: int = 0
    retr_size: int = 0
    retr_valid: bool = False
    retr_50: bool = False

    mod_origin: int = 0
    mod_origin_st: int = 0
    mod_extreme: int = 0
    mod_extreme_st: int = 0
    mod_size: int = 0
    mod_status: str = ""
    mod_owner: str = ""

    a_status: str = "NOT_IMPLEMENTED_CORE"
    events: list = field(default_factory=list)

    def ev(self, t: Tick, event: str, detail: str = "") -> None:
        self.events.append({
            "seq": t.seq, "time_ms": t.time_ms, "bar": t.bar,
            "gid": self.gid, "event": event, "detail": detail,
        })


class Reader:
    def __init__(self, ticks: list[Tick], reading_id: str = "L1"):
        self.ticks = ticks
        self.reading_id = reading_id
        self.reading = Reading(reading_id=reading_id)
        self.prev_close = 0
        self.cur_bar = -1
        self.last_price = 0
        self.last_time = 0
        self.bars: dict[int, dict] = {}
        self.trace: list[dict] = []
        self.events: list[dict] = []
        self._finished = False

    # ------------------------------------------------------------- bar helpers
    def _confirm_initial_one(self, t: Tick) -> None:
        r = self.reading
        b = self.bars[r.one_bar]
        d = 1 if b["c"] > b["o"] else (-1 if b["c"] < b["o"] else 0)
        if d == 0:
            d = 1 if b["c"] >= b["o"] else -1
        r.one_dir = d
        r.one_origin = b["h"] if d < 0 else b["l"]
        r.one_extreme = b["l"] if d < 0 else b["h"]
        r.one_size = abs(r.one_extreme - r.one_origin)
        r.one_extreme_st = t.time_ms
        r.one_status = "CONFIRMED"
        r.one_kt = t.time_ms
        r.phase = "WAIT_OPENING"
        r.ev(t, "ONE_CONFIRMED_INITIAL",
             f"dir={d} origin={r.one_origin} extreme={r.one_extreme} size={r.one_size}")

    def _freeze_one(self, t: Tick) -> None:
        r = self.reading
        if r.phase != "ONE_LIVE":
            return
        if r.one_size <= 0:
            r.one_bar = t.bar
            r.ev(t, "ONE_ZERO_SIZE_DEFERRAL", "1 sin medida; se difiere la pregunta por 2")
            return
        r.one_kt = self.last_time
        r.phase = "WAIT_OPENING"
        r.ev(t, "ONE_FROZEN",
             f"origin={r.one_origin} extreme={r.one_extreme} size={r.one_size}")

    # --------------------------------------------------------------- opening/2
    def _eval_opening(self, t: Tick) -> None:
        r = self.reading
        gap = t.price - self.prev_close
        r.two_origin = t.price
        r.two_extreme = t.price
        r.two_extreme_st = t.time_ms
        r.two_dir = r.one_dir
        r.two_st = t.time_ms
        r.two_bar = t.bar
        r.two_tail = 0
        r.two_seen_dir = False

        if abs(gap) >= PLANO:
            r.two_status = "IMPOSSIBLE_NO_FLAT"
            r.two_kt = t.time_ms
            r.ev(t, "TWO_IMPOSSIBLE_NO_FLAT",
                 f"|gap|={abs(gap)} >= {PLANO}; 2 prohibido")
            r.ev(t, "GAP_TRANSITION_PENDING",
                 "rama de gap no implementada en el nucleo; se resuelve por descarte")
            self._module_by_discard(t, include_two=False)
            return

        r.two_status = "CANDIDATE"
        r.phase = "TWO_LIVE"
        r.ev(t, "TWO_CANDIDATE",
             f"flat |gap|={abs(gap)} origin={t.price} dir={r.two_dir}")

    def _on_two_tick(self, t: Tick) -> None:
        r = self.reading
        d = r.two_dir
        if not r.two_seen_dir:
            if (t.price - r.two_origin) * d > 0:
                r.two_seen_dir = True
            else:
                r.two_tail = max(r.two_tail, (r.two_origin - t.price) * d)
        if (t.price - r.two_extreme) * d > 0:
            r.two_extreme = t.price
            r.two_extreme_st = t.time_ms
        r.two_size = abs(r.two_extreme - r.two_origin)

        if r.two_tail > PLANO:
            r.two_status = "IMPOSSIBLE_TAIL"
            r.two_kt = t.time_ms
            r.ev(t, "TWO_IMPOSSIBLE_TAIL", f"cola inicial={r.two_tail}")
            self._module_by_discard(t, include_two=False)
            return

        if r.two_size >= r.one_size:
            r.two_status = "CONFIRMED"
            r.two_kt = t.time_ms
            r.phase = "WAIT_THREE"
            r.retr_active = False
            r.retr_valid = False
            r.retr_50 = False
            r.ev(t, "TWO_CONFIRMED",
                 f"measure={r.two_size} >= 100% de 1 ({r.one_size})")

    # ------------------------------------------------------------------- three
    def _on_three_tick(self, t: Tick) -> None:
        r = self.reading
        d = r.two_dir

        # La candidatura de 2 pertenece a su vela: las vibraciones internas de
        # esa vela no fragmentan 2 ni abren 3. La pregunta por 3 comienza en la
        # vela siguiente, donde el retroceso ya es funcional.
        if t.bar <= r.two_bar:
            if (t.price - r.two_extreme) * d > 0:
                r.two_extreme = t.price
                r.two_extreme_st = t.time_ms
                r.two_size = abs(r.two_extreme - r.two_origin)
                r.ev(t, "TWO_EXTENDED",
                     f"extremo final de 2={t.price} size={r.two_size} (misma vela)")
            return

        # 2 confirmada sigue viva: mientras el precio haga nuevos extremos en
        # su direccion, 2 conserva la finalidad y actualiza su extremo final.
        if not r.retr_active:
            if (t.price - r.two_extreme) * d > 0:
                r.two_extreme = t.price
                r.two_extreme_st = t.time_ms
                r.two_size = abs(r.two_extreme - r.two_origin)
                r.ev(t, "TWO_EXTENDED",
                     f"extremo final de 2={t.price} size={r.two_size}")
                return
            r.retr_active = True
            r.retr_base_size = r.two_size
            r.retr_extreme = t.price
            r.retr_size = abs(t.price - r.two_extreme)
            r.retr_valid = False
            r.retr_50 = False
            r.ev(t, "RETRACE_START",
                 f"desde extremo final de 2 {r.two_extreme}; base={r.retr_base_size}")
        else:
            if (t.price - r.retr_extreme) * (-d) > 0:
                r.retr_extreme = t.price
            r.retr_size = abs(r.retr_extreme - r.two_extreme)

        if r.retr_base_size and r.retr_size * 2 > r.retr_base_size:
            r.three_status = "IMPOSSIBLE"
            r.retr_active = False
            r.ev(t, "THREE_IMPOSSIBLE_50",
                 f"retroceso={r.retr_size} > 50% de 2 ({r.retr_base_size / 2:.1f})")
            self._module_1_2(t)
            return

        if (r.retr_base_size and r.retr_size * 2 == r.retr_base_size
                and not r.retr_50):
            r.retr_50 = True
            r.ev(t, "FIFTY_PERCENT_EXACT",
                 f"retroceso={r.retr_size} = 50% de 2; frontera inclusiva")

        if r.retr_size >= NOISE:
            r.retr_valid = True

        # Recuperacion de la direccion de 2 y superacion estricta del extremo
        # final de 2: solo aqui nace 3, y solo tras un retroceso funcional.
        if (t.price - r.two_extreme) * d > 0:
            if r.retr_valid:
                r.three_status = "CONFIRMED"
                r.three_extreme = t.price
                r.three_extreme_st = t.time_ms
                r.three_st = r.two_extreme_st
                r.three_kt = t.time_ms
                r.ev(t, "THREE_CONFIRMED",
                     f"extremo={t.price} supera 2={r.two_extreme} "
                     f"retroceso={r.retr_size}")
                self._module_1_2_3(t)
                return
            # Retroceso absorbido por ruido: 2 conserva la finalidad.
            r.two_extreme = t.price
            r.two_extreme_st = t.time_ms
            r.two_size = abs(r.two_extreme - r.two_origin)
            r.retr_active = False
            r.ev(t, "TWO_ABSORBS_NOISE_RETRACE",
                 f"retroceso={r.retr_size} < {NOISE}; 2 continua")
            return

    def _on_three_live_tick(self, t: Tick) -> None:
        r = self.reading
        d = r.two_dir
        if (t.price - r.three_extreme) * d > 0:
            r.three_extreme = t.price
            r.three_extreme_st = t.time_ms
            r.mod_extreme = t.price
            r.mod_extreme_st = t.time_ms
            r.mod_size = abs(r.mod_extreme - r.mod_origin)
            r.ev(t, "THREE_EXTENDED",
                 f"extremo final de 3={t.price} modulo={r.mod_size}")

    # ------------------------------------------------------------------ modules
    def _module_by_discard(self, t: Tick, include_two: bool) -> None:
        r = self.reading
        r.mod_origin = r.one_origin
        r.mod_origin_st = r.one_st
        candidates = [(r.one_extreme, r.one_extreme_st, "1")]
        if include_two and r.two_extreme:
            candidates.append((r.two_extreme, r.two_extreme_st, "2"))
        if r.one_dir > 0:
            r.mod_extreme, r.mod_extreme_st, r.mod_owner = max(candidates)
        else:
            r.mod_extreme, r.mod_extreme_st, r.mod_owner = min(candidates)
        r.mod_size = abs(r.mod_extreme - r.mod_origin)
        r.mod_status = "BY_DISCARD_1_2" if include_two else "BY_DISCARD_1"
        r.three_status = "IMPOSSIBLE"
        r.phase = "CORE_A_NOT_IMPLEMENTED"
        r.a_status = "NOT_IMPLEMENTED_CORE"
        r.ev(t, "MODULE_BY_DISCARD",
             f"origin={r.mod_origin} extreme={r.mod_extreme} size={r.mod_size} "
             f"owner={r.mod_owner} status={r.mod_status}")

    def _module_1_2(self, t: Tick) -> None:
        r = self.reading
        r.mod_origin = r.one_origin
        r.mod_origin_st = r.one_st
        candidates = [(r.one_extreme, r.one_extreme_st, "1"),
                      (r.two_extreme, r.two_extreme_st, "2")]
        if r.one_dir > 0:
            r.mod_extreme, r.mod_extreme_st, r.mod_owner = max(candidates)
        else:
            r.mod_extreme, r.mod_extreme_st, r.mod_owner = min(candidates)
        r.mod_size = abs(r.mod_extreme - r.mod_origin)
        r.mod_status = "MODULE_1_2"
        r.three_status = "IMPOSSIBLE"
        r.phase = "CORE_A_NOT_IMPLEMENTED"
        r.a_status = "NOT_IMPLEMENTED_CORE"
        r.ev(t, "MODULE_1_2",
             f"origin={r.mod_origin} extreme={r.mod_extreme} size={r.mod_size} "
             f"owner={r.mod_owner}")

    def _module_1_2_3(self, t: Tick) -> None:
        r = self.reading
        r.mod_origin = r.one_origin
        r.mod_origin_st = r.one_st
        r.mod_extreme = r.three_extreme
        r.mod_extreme_st = r.three_extreme_st
        r.mod_owner = "3"
        r.mod_size = abs(r.mod_extreme - r.mod_origin)
        r.mod_status = "REGULAR_1_2_3"
        r.phase = "THREE_LIVE"
        r.a_status = "NOT_IMPLEMENTED_CORE"
        r.ev(t, "MODULE_1_2_3_CONFIRMED",
             f"origin={r.mod_origin} extreme={r.mod_extreme} size={r.mod_size}; "
             f"extremo de 3 vivo")

    # -------------------------------------------------------------------- loop
    def run(self) -> "Reader":
        r = self.reading
        for t in self.ticks:
            n_events = len(r.events)
            new_bar = t.bar != self.cur_bar
            if new_bar:
                if self.cur_bar != -1:
                    self._on_bar_close(self.cur_bar, self.last_price, self.last_time)
                self.cur_bar = t.bar
                b = self.bars.setdefault(t.bar, {"o": t.price, "h": t.price,
                                                 "l": t.price, "c": t.price})
                self._on_bar_open(t)
            else:
                b = self.bars[t.bar]
                b["h"] = max(b["h"], t.price)
                b["l"] = min(b["l"], t.price)
                b["c"] = t.price

            self.last_price = t.price
            self.last_time = t.time_ms
            r = self.reading

            if r.phase == "INITIAL_BAR":
                pass
            elif r.phase == "ONE_LIVE":
                if (t.price - r.one_extreme) * r.one_dir > 0:
                    r.one_extreme = t.price
                    r.one_extreme_st = t.time_ms
                    r.one_size = abs(r.one_extreme - r.one_origin)
            elif r.phase == "TWO_LIVE":
                self._on_two_tick(t)
            elif r.phase == "WAIT_THREE":
                self._on_three_tick(t)
            elif r.phase == "THREE_LIVE":
                self._on_three_live_tick(t)

            self.events.extend(r.events[n_events:])
            self.trace.append(self._snapshot(t))

        n_events = len(r.events)
        self._finalize()
        self.events.extend(r.events[n_events:])
        return self

    def _on_bar_open(self, t: Tick) -> None:
        r = self.reading
        if r.phase == "INITIAL_BAR":
            if r.one_bar == -1:
                r.one_bar = t.bar
                r.one_origin = t.price
                r.one_extreme = t.price
                r.one_st = t.time_ms
                r.one_status = "CANDIDATE"
                r.one_dir = 0
                r.ev(t, "ONE_CANDIDATE_INITIAL", f"open={t.price}")
                return
            if t.bar == r.one_bar:
                return
            self._confirm_initial_one(t)
            self._eval_opening(t)
            return
        if r.phase == "ONE_LIVE":
            self._freeze_one(t)
            if r.phase == "WAIT_OPENING":
                self._eval_opening(t)
            return
        if r.phase == "WAIT_OPENING":
            self._eval_opening(t)
            return
        # TWO_LIVE / WAIT_THREE / THREE_LIVE / CORE_A... continue across bars

    def _on_bar_close(self, bar: int, price: int, time_ms: int) -> None:
        self.prev_close = price
        r = self.reading
        if r.phase == "INITIAL_BAR":
            r.one_kt = time_ms
            r.ev(Tick(-1, time_ms, bar, price), "INITIAL_BAR_CLOSED", f"close={price}")
            return
        if r.phase == "TWO_LIVE":
            r.two_status = "IMPOSSIBLE_CLOSE"
            r.two_kt = time_ms
            r.ev(Tick(-1, time_ms, bar, price), "TWO_IMPOSSIBLE_CLOSE",
                 f"cierre sin 100% de 1: measure={r.two_size} one={r.one_size}")
            self._module_by_discard(Tick(-1, time_ms, bar, price), include_two=True)

    def _snapshot(self, t: Tick) -> dict:
        r = self.reading
        return {
            "sequence_id": t.seq, "time": _hhmm(t.time_ms), "price": t.price,
            "reading_id": r.reading_id, "gid": r.gid, "phase": r.phase,
            "one_dir": r.one_dir, "one_origin": r.one_origin,
            "one_extreme": r.one_extreme, "one_size": r.one_size,
            "two_status": r.two_status, "two_size": r.two_size,
            "two_extreme": r.two_extreme,
            "three_status": r.three_status, "three_extreme": r.three_extreme,
            "mod_status": r.mod_status, "mod_size": r.mod_size,
            "mod_origin": r.mod_origin, "mod_extreme": r.mod_extreme,
            "mod_owner": r.mod_owner, "a_status": r.a_status,
            "events": [e for e in r.events if e["seq"] == t.seq],
        }

    def _finalize(self) -> None:
        r = self.reading
        if r.phase in ("CORE_A_NOT_IMPLEMENTED",):
            r.phase = "CORE_MODULE_DONE_A_NOT_IMPLEMENTED"
        elif r.phase == "THREE_LIVE":
            r.phase = "CORE_THREE_LIVE_A_NOT_IMPLEMENTED"
        elif r.phase == "WAIT_THREE":
            r.phase = "CORE_WAIT_THREE_A_NOT_IMPLEMENTED"
        r.ev(Tick(-1, self.last_time, self.cur_bar, self.last_price), "CORE_END",
             f"phase={r.phase}; A/B/C no implementados")

    def summary(self) -> dict:
        r = self.reading
        return {
            "reader": CORE_VERSION,
            "reading_id": r.reading_id,
            "ticks": len(self.ticks),
            "phase": r.phase,
            "one": {"dir": r.one_dir, "origin": r.one_origin,
                    "extreme": r.one_extreme, "size": r.one_size,
                    "status": r.one_status},
            "two": {"origin": r.two_origin, "extreme": r.two_extreme,
                    "size": r.two_size, "status": r.two_status},
            "three": {"extreme": r.three_extreme, "status": r.three_status,
                      "kt": _hhmm(r.three_kt) if r.three_kt else ""},
            "module": {"origin": r.mod_origin, "extreme": r.mod_extreme,
                       "size": r.mod_size, "status": r.mod_status,
                       "owner": r.mod_owner},
            "a_status": r.a_status,
            "first_tick": self.ticks[0].seq if self.ticks else None,
            "last_tick": self.ticks[-1].seq if self.ticks else None,
        }


def _hhmm(ms: int) -> str:
    if not ms:
        return ""
    total = ms // 1000
    hh = (total // 3600) % 24
    mm = (total // 60) % 60
    ss = total % 60
    return f"{hh:02d}:{mm:02d}:{ss:02d}.{ms % 1000:03d}"


def _price(s: str) -> int:
    return int(round(float(s) * 100))


def load_ticks(path: Path) -> list[Tick]:
    out = []
    with path.open(encoding="utf-8-sig", newline="") as fh:
        for row in csv.DictReader(fh, delimiter=";"):
            out.append(Tick(int(row["sequence_id"]), int(row["time_msc"]),
                            int(row["time_msc"]) // 60000, _price(row["bid"])))
    return out


def _bar_of(h: str) -> int:
    hh, mm = h.split(":")
    return int(hh) * 60 + int(mm)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="t_from", default="16:15")
    ap.add_argument("--to", dest="t_to", default="17:29")
    ap.add_argument("--reading-id", default="L1")
    ap.add_argument("--trace")
    ap.add_argument("--events")
    ap.add_argument("--summary")
    args = ap.parse_args(argv)

    ticks = load_ticks(FEED)
    b0, b1 = _bar_of(args.t_from), _bar_of(args.t_to)
    ticks = [t for t in ticks if b0 <= t.bar % 1440 <= b1]
    rd = Reader(ticks, reading_id=args.reading_id).run()

    if args.trace:
        with open(args.trace, "w", encoding="utf-8") as fh:
            for row in rd.trace:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    if args.events:
        with open(args.events, "w", encoding="utf-8", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["sequence_id", "time", "bar", "gid", "event", "detail"])
            for e in rd.events:
                w.writerow([e["seq"], _hhmm(e["time_ms"]), e["bar"],
                            e["gid"], e["event"], e["detail"]])
    if args.summary:
        with open(args.summary, "w", encoding="utf-8") as fh:
            json.dump(rd.summary(), fh, indent=2, ensure_ascii=False)
    if not any([args.trace, args.events, args.summary]):
        print(json.dumps(rd.summary(), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
