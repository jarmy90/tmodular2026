# TM Core v0.7.5.1 - paquete reproducible

Este ZIP contiene fisicamente el motor legacy, el motor corregido, los tests,
los generadores, los dos feeds, el golden v003, las salidas completas y la
matriz de prefijos. No depende de archivos externos ni de rutas absolutas.

## Comando unico

```text
python -m pip install -r requirements.txt
python repro/run_all.py
```

El comando anterior ejecuta, en este orden:

1. motor corregido sobre el feed maestro y regeneracion de `out_v0751/`;
2. golden v003;
3. prefijos muestreados y matriz exhaustiva;
4. comparacion legacy/corregido;
5. R0062/R0064;
6. generalidad sintetica;
7. busqueda de hardcodes;
8. tests legacy y tests correctivos.

Resultado esperado:

- tests legacy: 20/20;
- tests correctivos: 7/7;
- motor: 86 lecturas, 1.399 eventos, 62 GAP, 1 secuencia local, 71 eventos locales;
- golden v003: 22/22;
- prefijos: 0 fallos;
- sinteticos: 2/2;
- hardcodes: 0 hits.

## Uso por separado

```text
python repro/generate_outputs.py
python audit_v0751/audit_v0751_golden.py
python audit_v0751/audit_v0751_prefix.py
python audit_v0751/audit_v0751_prefix_matrix.py
python audit_v0751/audit_v0751_compare.py
python audit_v0751/audit_v0751_r0062.py
python audit_v0751/audit_v0751_generality.py
python audit_v0751/audit_v0751_hardcodes.py
python -m pytest tests/legacy -q
python -m pytest audit_v0751/audit_v0751_tests.py -q
```

## Contenido

```text
python/TM_CORE_PYTHON_v075_STREAMING.py       motor legacy congelado
python/TM_CORE_PYTHON_v0751_STREAMING.py      motor v0.7.5.1
tests/legacy/test_v075_legacy.py              tests legacy, solo ruta adaptada
audit_v0751/audit_v0751_tests.py              tests correctivos
audit_v0751/audit_v0751_golden.py             comprobador golden v003
audit_v0751/audit_v0751_prefix.py             prefijos muestreados
audit_v0751/audit_v0751_prefix_matrix.py      matriz exhaustiva
audit_v0751/audit_v0751_availability.py       disponibilidad real de la capa local
audit_v0751/audit_v0751_compare.py            comparacion legacy/corregido
audit_v0751/audit_v0751_r0062.py              R0062 ventana base / R0064 completa
audit_v0751/audit_v0751_generality.py         espejo + desplazamiento de precio/tiempo
audit_v0751/audit_v0751_hardcodes.py          escaneo de valores prohibidos
data/TM_TICKFEED_1615_1730.csv                feed maestro
data/TM_TICKFEED_v010_LEGACY.csv              feed de los 20 tests legacy
data/lecturas_confirmadas_v003.txt            golden autoritativo
out_v0751/                                    salidas completas
diff/v075_to_v0751.diff                       diff unificado
manifest.json                                 hashes de archivos internos
SHA256SUMS.txt                                hashes del paquete
```

## Golden 22/22: que demuestra y que no

El golden v003 **no** es una tabla usada para construir la salida. La salida
local sale de `detect_local_sequences()` dentro del motor, usando puntos,
barras y movimientos. El comprobador `audit_v0751_golden.py` es externo y solo
compara la salida ya emitida.

Las 22 comprobaciones son:

- 6 estructurales del nucleo principal: R0001, modulo 16:15, plano 16:16,
  estructura 16:15-16:18, AUT bajista 16:18 y TT pendiente en 16:18;
- 15 comprobaciones de la capa local 1-2-3/AUT en 16:19-16:24;
- 1 comprobacion de completitud: al menos 15 eventos locales.

Por tanto el golden 22/22 corresponde a **dos capas**: nucleo principal para
las 6 estructurales y capa local paralela para las 15 locales, mas un chequeo
de completitud. No es una unica cadena de eventos del nucleo.

## Capa local: contrato real

- **Entrada:** `engine.points`, `engine.bars` y `engine.movements`.
- **Estado:** `LocalSequence` por cada 1-2-3 valido; `LocalLeg` por cada
  1, 2, 3, A, B, AUT y extensiones posteriores.
- **Salida:** `engine.local_sequences` y `engine.local_events`.
- **Relacion con la lectura principal:** es una capa paralela de lectura; no
  crea ni posee `Reading`, no altera el nucleo, no cambia IDs principales.
- **Ownership:** el nucleo conserva el ownership de sus lecturas; la capa local
  no es propietaria de ticks ni de lecturas principales.
- **Dominancia:** la capa local no domina ni reemplaza la lectura principal.
- **Persistencia:** una secuencia local puede prolongarse en barras posteriores
  con nuevas A, B, AUT y nuevos 1; termina al agotarse el feed o la estructura.
- **Reglas generales:** 1 con recorrido >= MOVE; 2 en plano, sin cola inicial y
  tamano >= 1; 3 con nuevo extremo; A contraria; B supera el 100 % de A; AUT
  supera el origen correspondiente; nuevo 1 dominante. Sin horas ni precios
  grabados en el motor.
- **Causalidad de etiquetas:** `confirmation_time` es el tiempo estructural del
  extremo/confirmacion, no necesariamente el instante en que la secuencia pudo
  detectarse. La capa 1-2-3 requiere tres barras y el tramo posterior requiere
  movimientos confirmados. Por eso el paquete publica tambien
  `out_v0751/local_availability.json` con el primer tick en que cada evento
  aparece realmente en un prefijo.

La matriz de prefijos usa esa disponibilidad medida para juzgar la capa local.
No afirma que los 71 eventos locales fueran conocidos en su
`confirmation_time`. En esta implementacion hay 16 eventos con retraso de
disponibilidad; el maximo es 69.287 s. Si se exigiera conocimiento local en el
mismo `confirmation_time`, haria falta un cambio funcional del motor, que este
paquete no hace.

## Prefijos

`out_v0751/prefix_matrix_v0751.json` contiene 733 cortes unicos:

- cierre de las 75 velas;
- antes y despues de la confirmacion estructural de cada evento local;
- antes y despues de la disponibilidad real de cada evento local;
- 500 cortes pseudoaleatorios con semilla publicada `20261028`;
- hitos y eventos de R0062/R0064.

La comparacion principal exige igualdad exacta de eventos conocidos. La capa
local exige igualdad exacta contra los eventos cuya disponibilidad medida ya
ocurrio. Resultado esperado: `failures = 0`.

## Comparacion legacy/corregido

`readings_identical=true` **no se presenta como mejora funcional**. Solo indica
que el nucleo conserva sus 86 lecturas. La mejora medida es la eliminacion de
12 GAP con `abs(gap) < 0.25`: 74 -> 62. Los 1.399 eventos restantes coinciden
salvo el desplazamiento de IDs.

## Limites

- No se implementa AFS2.
- No se resuelve FT.
- `AFS2_READY` sigue en `false`.
- Queda una lectura abierta al final, R0086.
- No se declara produccion.
