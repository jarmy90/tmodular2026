from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import TM_CORE_PYTHON_v075_STREAMING as legacy  # noqa: E402
import TM_CORE_PYTHON_v0751_STREAMING as corrected  # noqa: E402

FEED = ROOT / "data" / "TM_TICKFEED_1615_1730.csv"
OUT = ROOT / "out_v0751"
REPORT = ROOT / "repro" / "compare.json"

READING_FIELDS = (
    "reading_id",
    "direction",
    "state",
    "created_time",
    "module_origin",
    "module_extreme",
    "a_origin",
    "a_end",
    "b_origin",
    "b_extreme",
    "tt_target",
    "tt_hit",
    "ft",
)


def reading_signature(reading) -> tuple:
    return tuple(getattr(reading, name) for name in READING_FIELDS)


def event_signature(event: dict) -> tuple:
    return tuple(
        (key, value)
        for key, value in event.items()
        if key not in {"event_id"}
    )


def main() -> int:
    old_points, old_bars = legacy.load_feed(FEED)
    old = legacy.run_engine(old_points, old_bars)
    new_points, new_bars = corrected.load_feed(FEED)
    new = corrected.run_engine(new_points, new_bars)

    removed_gaps = [
        event
        for event in old.events
        if event["function"] == "GAP" and abs(event["gap"]) < corrected.PLANO_TICK
    ]
    old_kept = [event for event in old.events if event not in removed_gaps]
    readings_identical = [reading_signature(item) for item in old.readings] == [
        reading_signature(item) for item in new.readings
    ]
    events_identical = [event_signature(item) for item in old_kept] == [
        event_signature(item) for item in new.events
    ]

    with (OUT / "v0751_GapsEspuriosEliminados.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as fh:
        writer = csv.writer(fh)
        writer.writerow(["old_event_id", "bar_time", "gap", "reason"])
        for event in removed_gaps:
            writer.writerow(
                [
                    event["event_id"],
                    event["bar_time"],
                    f"{event['gap'] / 100:.2f}",
                    event.get("reason", ""),
                ]
            )

    with (OUT / "v0751_CorrespondenciaEventos.csv").open(
        "w", newline="", encoding="utf-8-sig"
    ) as fh:
        writer = csv.writer(fh)
        writer.writerow(
            ["old_event_id", "new_event_id", "function", "bar_time", "reading_id"]
        )
        for before, after in zip(old_kept, new.events):
            writer.writerow(
                [
                    before["event_id"],
                    after["event_id"],
                    before["function"],
                    before["bar_time"],
                    before["reading_id"],
                ]
            )

    result = {
        "legacy": {"readings": len(old.readings), "events": len(old.events)},
        "corrected": {"readings": len(new.readings), "events": len(new.events)},
        "removed_gap_events": len(removed_gaps),
        "removed_gap_values": [event["gap"] for event in removed_gaps],
        "readings_identical": readings_identical,
        "remaining_events_identical": events_identical,
        "corrected_gap_events": sum(
            1 for event in new.events if event["function"] == "GAP"
        ),
        "interpretation": (
            "La mejora es la eliminacion de GAP con |gap| < 0.25. "
            "No se usa readings_identical como mejora funcional."
        ),
    }
    assert len(old_kept) == len(new.events), result
    assert removed_gaps and all(abs(event["gap"]) < 25 for event in removed_gaps)
    assert readings_identical and events_identical, result
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
