from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "repro" / "hardcodes.json"
EXCLUDED = {
    "audit_v0751/audit_v0751_golden.py",
    "audit_v0751/audit_v0751_tests.py",
    "audit_v0751/audit_v0751_hardcodes.py",
    "audit_v0751/audit_v0751_prefix.py",
    "audit_v0751/audit_v0751_prefix_matrix.py",
    "audit_v0751/audit_v0751_compare.py",
    "audit_v0751/audit_v0751_r0062.py",
    "audit_v0751/audit_v0751_generality.py",
}
PRICES = [
    "29850.0",
    "29842.5",
    "29844.8",
    "29832.5",
    "29830.3",
    "29850.8",
    "29852.6",
    "29837.3",
    "29833.3",
    "29840.6",
    "29828.1",
]
TIMES = ["16:19", "16:20", "16:21", "16:22", "16:23", "16:24"]
SEQUENCES = ["1809", "1846", "1879", "2062", "2078", "2107", "2165", "2259"]


def patterns() -> dict[str, list[str]]:
    result = {"time": TIMES, "sequence_id": SEQUENCES, "price": []}
    for value in PRICES:
        result["price"].append(value)
        result["price"].append(str(int(round(float(value) * 100))))
    return result


def main() -> int:
    checks = patterns()
    files = []
    for path in sorted((ROOT / "python").glob("*.py")):
        files.append(path)
    for path in sorted((ROOT / "audit_v0751").glob("*.py")):
        files.append(path)
    for path in sorted((ROOT / "repro").glob("*.py")):
        files.append(path)
    hits = []
    scanned = []
    for path in files:
        rel = path.relative_to(ROOT).as_posix()
        if rel in EXCLUDED:
            continue
        scanned.append(rel)
        text = path.read_text(encoding="utf-8")
        for category, values in checks.items():
            for value in values:
                if category == "sequence_id":
                    found = re.search(rf"(?<!\d){re.escape(value)}(?!\d)", text)
                else:
                    found = value in text
                if found:
                    hits.append({"file": rel, "category": category, "value": value})
    result = {
        "scanned_files": scanned,
        "excluded_as_test_or_golden": sorted(EXCLUDED),
        "forbidden_times": TIMES,
        "forbidden_prices": PRICES,
        "forbidden_sequence_ids": SEQUENCES,
        "hits": hits,
        "pass": not hits,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not hits else 1


if __name__ == "__main__":
    raise SystemExit(main())
