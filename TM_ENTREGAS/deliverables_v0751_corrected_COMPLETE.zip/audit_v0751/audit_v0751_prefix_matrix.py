﻿from __future__ import annotations

import bisect
import json
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import TM_CORE_PYTHON_v0751_STREAMING as core  # noqa: E402
import audit_v0751_availability as availability_mod  # noqa: E402

FEED = ROOT / "data" / "TM_TICKFEED_1615_1730.csv"
OUT = ROOT / "out_v0751" / "prefix_matrix_v0751.json"
SEED = 20261028


def event_signature(event: dict) -> tuple:
    return (
        event.get("function"),
        event.get("bar_time"),
        event.get("direction"),
        event.get("reading_id"),
        event.get("origin"),
        event.get("extreme"),
        event.get("size"),
        event.get("tt_target"),
        event.get("tt_100"),
        event.get("ft"),
        event.get("reason"),
    )


def local_signature(event: dict) -> tuple:
    return (
        event["sequence_id"],
        event["function"],
        event["bar_time"],
        event["direction"],
        event["origin"],
        event["extreme"],
        event["size"],
        event["confirmation_time_ms"],
    )


def main() -> int:
    points, bars = core.load_feed(FEED)
    full = core.run_engine(points, bars)
    availability = availability_mod.build()
    availability_by_id = {
        row["local_event_id"]: row["availability_time_ms"]
        for row in availability["rows"]
    }
    times = sorted({point.time_ms for point in points})

    def at_or_before(value: int) -> int:
        index = bisect.bisect_right(times, value) - 1
        return times[max(index, 0)]

    cutoffs: dict[int, set[str]] = {}

    def add(value: int | None, label: str) -> None:
        if value is not None:
            cutoffs.setdefault(at_or_before(value), set()).add(label)

    for bar in sorted(bars.values(), key=lambda item: item.idx):
        add(bar.last.time_ms, "bar_close")
    for event in full.local_events:
        confirmation = event["confirmation_time_ms"]
        index = bisect.bisect_left(times, confirmation)
        if index > 0:
            cutoffs.setdefault(times[index - 1], set()).add(
                "local_before_confirmation"
            )
        add(confirmation, "local_after_confirmation")
        available = availability_by_id[event["local_event_id"]]
        available_index = bisect.bisect_left(times, available)
        if available_index > 0:
            cutoffs.setdefault(times[available_index - 1], set()).add(
                "local_before_availability"
            )
        add(available, "local_after_availability")
    for reading in full.readings:
        if reading.reading_id not in {"R0062", "R0064"}:
            continue
        for value in (
            reading.created_time,
            reading.module_origin_time,
            reading.module_extreme_time,
            reading.a_end_time,
            reading.b_extreme_time,
            reading.tt_time,
            reading.tt_knowledge_time,
            reading.b_grande_time,
            reading.ft_time,
        ):
            add(value, f"milestone_{reading.reading_id}")
    for event in full.events:
        if event["reading_id"] in {"R0062", "R0064"}:
            add(event.get("structural_time_ms"), f"event_{event['reading_id']}")
            add(event.get("confirmation_time_ms"), f"event_{event['reading_id']}")
            add(event.get("knowledge_time_ms"), f"event_{event['reading_id']}")

    rng = random.Random(SEED)
    for value in rng.sample(times, 500):
        cutoffs.setdefault(value, set()).add("random_500")

    rows: list[dict] = []
    failures: list[dict] = []
    for cutoff in sorted(cutoffs):
        prefix_points = [point for point in points if point.time_ms <= cutoff]
        if not prefix_points:
            continue
        prefix = core.run_engine(prefix_points, bars)
        expected_events = [
            event_signature(event)
            for event in full.events
            if event["knowledge_time_ms"] <= cutoff
            and event["function"] not in {"FIN_FEED", "START"}
            and event.get("reason") != "END_OF_FEED"
        ]
        observed_events = [
            event_signature(event)
            for event in prefix.events
            if event["knowledge_time_ms"] <= cutoff
            and event["function"] not in {"FIN_FEED", "START"}
            and event.get("reason") != "END_OF_FEED"
        ]
        expected_local = [
            local_signature(event)
            for event in full.local_events
            if availability_by_id[event["local_event_id"]] <= cutoff
        ]
        observed_local = [
            local_signature(event)
            for event in prefix.local_events
            if event["confirmation_time_ms"] <= cutoff
        ]
        ok = expected_events == observed_events and expected_local == observed_local
        row = {
            "cutoff_ms": cutoff,
            "cutoff": core.ms_to_text(cutoff),
            "classes": sorted(cutoffs[cutoff]),
            "points": len(prefix_points),
            "events": len(observed_events),
            "local": len(observed_local),
            "pass": ok,
        }
        rows.append(row)
        if not ok:
            failures.append(
                {
                    **row,
                    "events_expected": len(expected_events),
                    "events_observed": len(observed_events),
                    "local_expected": len(expected_local),
                    "local_observed": len(observed_local),
                }
            )

    by_class: dict[str, int] = {}
    for labels in cutoffs.values():
        for label in labels:
            by_class[label] = by_class.get(label, 0) + 1
    result = {
        "seed": SEED,
        "feed_points": len(points),
        "bars": len(bars),
        "bar_closes": sum(1 for _ in bars.values()),
        "local_events": len(full.local_events),
        "local_lagged_events": availability["lagged_events"],
        "local_max_lag_ms": availability["max_lag_ms"],
        "random_cutoffs_requested": 500,
        "cutoffs": len(rows),
        "by_class": by_class,
        "failures": len(failures),
        "failure_detail": failures,
        "rows": rows,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        f"PREFIJOS MATRIZ: fallos={result['failures']} cortes={result['cutoffs']} "
        f"velas={result['bar_closes']} random={result['random_cutoffs_requested']} seed={SEED}"
    )
    for failure in failures[:5]:
        print("FAIL", failure)
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
