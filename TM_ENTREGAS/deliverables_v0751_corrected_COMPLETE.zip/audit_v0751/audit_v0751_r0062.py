from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import TM_CORE_PYTHON_v0751_STREAMING as core  # noqa: E402

FEED = ROOT / "data" / "TM_TICKFEED_1615_1730.csv"
LEGACY_FEED = ROOT / "data" / "TM_TICKFEED_v010_LEGACY.csv"
OUT = ROOT / "out_v0751" / "R0062_R0064.json"


def reading_payload(reading) -> dict:
    return {
        "reading_id": reading.reading_id,
        "state": reading.state,
        "module": f"{core.price_s(reading.module_origin)}->{core.price_s(reading.module_extreme)}",
        "x": core.price_s(reading.module_size),
        "a": f"{core.price_s(reading.a_origin)}->{core.price_s(reading.a_end)}",
        "a_size": core.price_s(reading.a_size),
        "b": f"{core.price_s(reading.b_origin)}->{core.price_s(reading.b_extreme)}",
        "b_size": core.price_s(reading.b_size),
        "tt_target": reading.tt_target,
        "tt_price": reading.tt_price,
        "tt_hit": reading.tt_hit,
        "ft": reading.ft,
        "ft_price": reading.ft_price,
        "ft_structural_time": reading.ft_structural_time,
    }


def main() -> int:
    points, bars = core.load_feed(FEED)
    full = core.run_engine(points, bars)
    full_reading = next(
        (
            reading
            for reading in full.readings
            if reading.module_origin == 2966730
            and reading.module_extreme == 2960210
        ),
        None,
    )
    assert full_reading is not None
    legacy_points, legacy_bars = core.load_feed(LEGACY_FEED)
    window = core.run_engine(legacy_points, legacy_bars)
    base_reading = next(
        (
            reading
            for reading in window.readings
            if reading.module_origin == 2966730
            and reading.module_extreme == 2960210
        ),
        None,
    )
    assert base_reading is not None
    assert base_reading.reading_id == "R0062", base_reading.reading_id
    assert full_reading.reading_id == "R0064", full_reading.reading_id

    full_events = [
        event for event in full.events if event["reading_id"] == full_reading.reading_id
    ]
    base_events = [
        event for event in window.events if event["reading_id"] == base_reading.reading_id
    ]
    assert len(full_events) == 26
    assert len(base_events) == 26
    assert full_reading.state == "DONE"
    assert full_reading.a_origin == 2960210
    assert full_reading.a_end == 2968040
    assert full_reading.b_origin == 2968040
    assert full_reading.b_extreme == 2960020
    assert full_reading.tt_target == 2961520
    assert full_reading.tt_hit is True
    assert full_reading.tt_price == 2961420
    assert full_reading.ft is True
    assert full_reading.ft_price == 2962110
    assert full_reading.ft_structural_time == 1792169846302

    result = {
        "base_window": {"feed": "TM_TICKFEED_v010_LEGACY.csv", "reading": reading_payload(base_reading), "events": len(base_events)},
        "full_window": {"feeding": "complete_master", "reading": reading_payload(full_reading), "events": len(full_events)},
        "correspondence": True,
        "checks": {
            "module": full_reading.module_origin == 2966730 and full_reading.module_extreme == 2960210,
            "a": full_reading.a_origin == 2960210 and full_reading.a_end == 2968040,
            "b": full_reading.b_origin == 2968040 and full_reading.b_extreme == 2960020,
            "tt": full_reading.tt_target == 2961520 and full_reading.tt_price == 2961420,
            "ft": full_reading.ft is True and full_reading.ft_price == 2962110,
        },
    }
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
