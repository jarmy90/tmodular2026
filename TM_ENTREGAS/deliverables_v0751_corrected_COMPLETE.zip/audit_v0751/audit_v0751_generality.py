from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import TM_CORE_PYTHON_v0751_STREAMING as core  # noqa: E402

FEED = ROOT / "data" / "TM_TICKFEED_1615_1730.csv"
OUT = ROOT / "out_v0751" / "generalidad_sintetica.json"


def build_bars(points: list[core.Pt]) -> dict[int, core.Bar]:
    bars: dict[int, core.Bar] = {}
    for point in points:
        bar = bars.get(point.bar)
        if bar is None:
            prev = bars[max(bars)].last.price if bars else None
            gap = point.price - prev if prev is not None else 0
            bars[point.bar] = core.Bar(
                point.bar,
                core.ms_to_hms(point.bar * 60000)[:5],
                point,
                point,
                point,
                point,
                prev,
                gap,
            )
        else:
            if point.price > bar.high.price:
                bar.high = point
            if point.price < bar.low.price:
                bar.low = point
            bar.last = point
    return bars


def transformed(points: list[core.Pt], mirror: int, shift: int, time_shift: int) -> list[core.Pt]:
    return [
        core.Pt(
            2 * mirror - point.price + shift,
            point.seq,
            point.time_ms + time_shift,
            (point.time_ms + time_shift) // 60000,
        )
        for point in points
    ]


def compare_case(name: str, base, points, mirror: int, shift: int, time_shift: int) -> dict:
    moved = transformed(points, mirror, shift, time_shift)
    engine = core.run_engine(moved, build_bars(moved))
    assert len(engine.local_sequences) == len(base.local_sequences), name
    comparisons = []
    for original, changed in zip(base.local_sequences, engine.local_sequences):
        assert original.direction == -changed.direction, name
        assert len(original.legs) == len(changed.legs), name
        for left, right in zip(original.legs, changed.legs):
            assert left.function == right.function, (name, left.function, right.function)
            assert left.direction == -right.direction, name
            assert left.size == right.size, name
            assert 2 * mirror + shift - right.origin == left.origin, name
            assert 2 * mirror + shift - right.extreme == left.extreme, name
            assert right.origin_time - left.origin_time == time_shift, name
            assert right.extreme_time - left.extreme_time == time_shift, name
            assert right.confirmation_time - left.confirmation_time == time_shift, name
            comparisons.append(
                {
                    "function": left.function,
                    "size": left.size,
                    "source_direction": left.direction,
                    "synthetic_direction": right.direction,
                    "time_shift_ms": right.confirmation_time
                    - left.confirmation_time,
                    "price_roundtrip_ok": True,
                }
            )
    return {
        "name": name,
        "mirror": mirror,
        "price_shift": shift,
        "time_shift_ms": time_shift,
        "sequences": len(engine.local_sequences),
        "legs": comparisons,
        "pass": True,
    }


def main() -> int:
    points, bars = core.load_feed(FEED)
    base = core.run_engine(points, bars)
    assert base.local_sequences
    cases = [
        compare_case(
            "mirror_shift_time",
            base,
            points,
            mirror=3_000_000,
            shift=12_345,
            time_shift=7_200_000,
        ),
        compare_case(
            "mirror_shift_time_alt",
            base,
            points,
            mirror=4_500_000,
            shift=-67_890,
            time_shift=13 * 60_000,
        ),
    ]
    result = {
        "base_sequence_count": len(base.local_sequences),
        "base_functions": [leg.function for leg in base.local_sequences[0].legs],
        "cases": cases,
        "pass": all(case["pass"] for case in cases),
    }
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
