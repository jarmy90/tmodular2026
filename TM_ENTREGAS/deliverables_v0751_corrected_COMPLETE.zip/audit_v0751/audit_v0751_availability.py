﻿from __future__ import annotations

import bisect
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import TM_CORE_PYTHON_v0751_STREAMING as core  # noqa: E402

FEED = ROOT / "data" / "TM_TICKFEED_1615_1730.csv"
OUT = ROOT / "out_v0751" / "local_availability.json"


def signature(event: dict) -> tuple:
    return (
        event["function"],
        event["bar_time"],
        event["direction"],
        event["origin"],
        event["extreme"],
        event["confirmation_time_ms"],
    )


def build() -> dict:
    points, bars = core.load_feed(FEED)
    full = core.run_engine(points, bars)
    full_signatures = [signature(event) for event in full.local_events]
    cache: dict[int, set[tuple]] = {}

    def local_at(index: int) -> set[tuple]:
        if index not in cache:
            engine = core.run_engine(points[: index + 1], bars)
            cache[index] = {signature(event) for event in engine.local_events}
        return cache[index]

    rows = []
    for event, sig in zip(full.local_events, full_signatures):
        confirmation = event["confirmation_time_ms"]
        start = max(0, bisect.bisect_left([point.time_ms for point in points], confirmation))
        end = len(points) - 1
        assert sig in local_at(end), event["local_event_id"]
        lo, hi = start, end
        while lo < hi:
            mid = (lo + hi) // 2
            if sig in local_at(mid):
                hi = mid
            else:
                lo = mid + 1
        availability = points[lo].time_ms
        assert sig in local_at(lo)
        rows.append(
            {
                "local_event_id": event["local_event_id"],
                "function": event["function"],
                "bar_time": event["bar_time"],
                "confirmation_time_ms": confirmation,
                "confirmation_time": core.ms_to_text(confirmation),
                "availability_time_ms": availability,
                "availability_time": core.ms_to_text(availability),
                "lag_ms": availability - confirmation,
                "availability_index": lo,
            }
        )
    result = {
        "feed": FEED.name,
        "local_events": len(rows),
        "max_lag_ms": max(row["lag_ms"] for row in rows),
        "lagged_events": sum(1 for row in rows if row["lag_ms"] > 0),
        "rows": rows,
    }
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        f"LOCAL AVAILABILITY: events={result['local_events']} "
        f"lagged={result['lagged_events']} max_lag_ms={result['max_lag_ms']}"
    )
    return result


if __name__ == "__main__":
    build()
