from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
sys.path.insert(0, str(ROOT / "audit_v0751"))
sys.path.insert(0, str(ROOT / "repro"))

import audit_v0751_compare as compare  # noqa: E402
import audit_v0751_generality as generality  # noqa: E402
import audit_v0751_golden as golden  # noqa: E402
import audit_v0751_hardcodes as hardcodes  # noqa: E402
import audit_v0751_prefix as prefix_sample  # noqa: E402
import audit_v0751_prefix_matrix as prefix_matrix  # noqa: E402
import audit_v0751_r0062 as r0062  # noqa: E402
import generate_outputs  # noqa: E402


def sanitize(text: str) -> str:
    text = text.replace(str(ROOT), "<PACKAGE>")
    text = text.replace(str(ROOT.parent), "<PACKAGE_PARENT>")
    text = re.sub(r"[A-Za-z]:\\[^\s\"']+", "<ABSOLUTE_PATH>", text)
    text = re.sub(r"/Users/[^\s\"']+", "<ABSOLUTE_PATH>", text)
    return text


def run_pytest(path: str, log_name: str) -> dict:
    command = [
        sys.executable,
        "-m",
        "pytest",
        path,
        "-q",
        "--color=no",
        "-p",
        "no:cacheprovider",
    ]
    completed = subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    output = sanitize((completed.stdout + completed.stderr).strip())
    log = ROOT / "audit_v0751" / log_name
    log.write_text(output + "\n", encoding="utf-8")
    print(output)
    return {
        "command": " ".join(command[1:]),
        "returncode": completed.returncode,
        "passed": completed.returncode == 0,
        "log": log.relative_to(ROOT).as_posix(),
        "output": output,
    }


def main() -> int:
    engine = generate_outputs.main()
    golden.main()
    prefix_sample.main()
    prefix_matrix.main()
    compare.main()
    r0062.main()
    generality.main()
    hardcodes.main()

    legacy = run_pytest("tests/legacy", "legacy_tests.txt")
    corrected = run_pytest(
        "audit_v0751/audit_v0751_tests.py", "corrected_tests.txt"
    )

    golden_json = json.loads(
        (ROOT / "out_v0751" / "golden_v003.json").read_text(encoding="utf-8")
    )
    prefix_json = json.loads(
        (ROOT / "out_v0751" / "prefix_v0751.json").read_text(encoding="utf-8")
    )
    prefix_matrix_json = json.loads(
        (ROOT / "out_v0751" / "prefix_matrix_v0751.json").read_text(encoding="utf-8")
    )
    compare_json = json.loads(
        (ROOT / "repro" / "compare.json").read_text(encoding="utf-8")
    )
    hardcode_json = json.loads(
        (ROOT / "repro" / "hardcodes.json").read_text(encoding="utf-8")
    )
    generality_json = json.loads(
        (ROOT / "out_v0751" / "generalidad_sintetica.json").read_text(encoding="utf-8")
    )
    r0062_json = json.loads(
        (ROOT / "out_v0751" / "R0062_R0064.json").read_text(encoding="utf-8")
    )
    availability_json = json.loads(
        (ROOT / "out_v0751" / "local_availability.json").read_text(encoding="utf-8")
    )

    checks = {
        "legacy_tests": legacy["passed"],
        "corrected_tests": corrected["passed"],
        "engine_counts": engine["readings"] == 86
        and engine["events"] == 1399
        and engine["gap_events"] == 62,
        "golden_22": golden_json["passed"] == golden_json["total"] == 22,
        "sample_prefix": prefix_json["failures"] == 0,
        "full_prefix": prefix_matrix_json["failures"] == 0,
        "comparison": compare_json["readings_identical"]
        and compare_json["remaining_events_identical"]
        and compare_json["removed_gap_events"] == 12,
        "r0062_r0064": r0062_json["correspondence"],
        "generality": generality_json["pass"],
        "hardcodes": hardcode_json["pass"],
    }
    report = {
        "package": "deliverables_v0751_corrected_COMPLETE",
        "version": "0.7.5.1",
        "single_command": "python repro/run_all.py",
        "engine": engine,
        "legacy_tests": legacy,
        "corrected_tests": corrected,
        "golden_v003": {
            "passed": golden_json["passed"],
            "total": golden_json["total"],
        },
        "prefix_sample": {
            "cases": len(prefix_json["rows"]),
            "failures": prefix_json["failures"],
        },
        "prefix_matrix": {
            "cutoffs": prefix_matrix_json["cutoffs"],
            "bar_closes": prefix_matrix_json["bar_closes"],
            "random_cutoffs": prefix_matrix_json["random_cutoffs_requested"],
            "seed": prefix_matrix_json["seed"],
            "by_class": prefix_matrix_json["by_class"],
            "failures": prefix_matrix_json["failures"],
        },
        "local_availability": {
            "events": availability_json["local_events"],
            "lagged_events": availability_json["lagged_events"],
            "max_lag_ms": availability_json["max_lag_ms"],
        },
        "comparison": compare_json,
        "r0062_r0064": r0062_json,
        "generality": generality_json,
        "hardcodes": hardcode_json,
        "checks": checks,
        "pass": all(checks.values()),
    }
    (ROOT / "repro" / "REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"checks": checks, "pass": report["pass"]}, ensure_ascii=False, indent=2))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
