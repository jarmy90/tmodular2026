from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FEED = DATA / "TM_TICKFEED_1615_1730.csv"
LEGACY_FEED = DATA / "TM_TICKFEED_v010_LEGACY.csv"
GOLDEN = DATA / "lecturas_confirmadas_v003.txt"
OUT = ROOT / "out_v0751"
REPORT = ROOT / "repro" / "REPORT.json"
