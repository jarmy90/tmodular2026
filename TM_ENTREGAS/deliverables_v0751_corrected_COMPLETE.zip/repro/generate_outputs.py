from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))

import TM_CORE_PYTHON_v0751_STREAMING as core  # noqa: E402

from paths import FEED, OUT  # noqa: E402


def main() -> dict:
    points, bars = core.load_feed(FEED)
    engine = core.run_engine(points, bars)
    paths = core.write_outputs(engine, OUT, "v0751")
    info = json.loads((OUT / "v0751_Informe.json").read_text(encoding="utf-8"))
    result = {
        "feed_points": len(points),
        "bars": len(bars),
        "readings": len(engine.readings),
        "events": len(engine.events),
        "gap_events": sum(1 for event in engine.events if event["function"] == "GAP"),
        "movements": len(engine.movements),
        "local_sequences": len(engine.local_sequences),
        "local_events": len(engine.local_events),
        "outputs": [path.relative_to(ROOT).as_posix() for path in paths],
        "info_counts": {
            "readings": info["readings"],
            "events": info["events"],
            "local_sequences": info["local_sequences"],
            "local_events": info["local_events"],
        },
    }
    assert result["readings"] == 86, result
    assert result["events"] == 1399, result
    assert result["gap_events"] == 62, result
    assert result["local_sequences"] == 1, result
    assert result["local_events"] == 71, result
    assert all(result["readings"] == result["info_counts"]["readings"] for _ in (0,))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


if __name__ == "__main__":
    main()
