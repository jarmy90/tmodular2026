from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "manifest.json"
SUMS = ROOT / "SHA256SUMS.txt"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def main() -> None:
    files = sorted(
        path
        for path in ROOT.rglob("*")
        if path.is_file() and path not in {MANIFEST, SUMS}
    )
    records = {}
    for path in files:
        rel = path.relative_to(ROOT).as_posix()
        records[rel] = {"bytes": path.stat().st_size, "sha256": sha256(path)}
    manifest = {
        "package": "deliverables_v0751_corrected_COMPLETE",
        "version": "0.7.5.1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "path_style": "relative_posix",
        "file_count": len(records),
        "files": records,
        "excluded": ["manifest.json", "SHA256SUMS.txt"],
    }
    MANIFEST.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    all_files = sorted(
        path for path in ROOT.rglob("*") if path.is_file() and path != SUMS
    )
    lines = []
    for path in all_files:
        rel = path.relative_to(ROOT).as_posix()
        lines.append(f"{sha256(path)}  {rel}")
    SUMS.write_text("\n".join(lines) + "\n", encoding="ascii")
    print(
        json.dumps(
            {
                "manifest_files": len(records),
                "sha256sums_files": len(lines),
                "manifest": MANIFEST.name,
                "sha256sums": SUMS.name,
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
