"""TM Core v0.7.5 - lector funcional streaming, causal y auditable."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
import tempfile
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

VERSION = "0.7.5"
PRICE_SCALE = 100
MOVE = 600
STRUCTURAL_MOVE = 200
RETRACE_NUM = 25
RETRACE_DEN = 100
AUT_NUM = 127
AUT_DEN = 100
AUT_EXTRA = 25
CUT_BUFFER = 200
MIN_MODULE = 1000
A_SIGNIFICANT_NUM = 75
A_SIGNIFICANT_DEN = 100
A_MAX_MODULE_MULTIPLE = 2.0
MAX_ACTIVE = 3
WINDOW_START = "16:52:00"
WINDOW_END = "17:01:00"

FUNCTION_LABELS = {
    "1",
    "A",
    "B",
    "C",
    "AUT",
    "TT",
    "FT",
    "CUT",
    "GAP",
    "B_GRANDE",
    "B_FALLIDA",
    "B_OSCILACION",
    "C_CAND",
    "C_CANCELADA",
    "A_SIGNIFICATIVA",
    "A_DESPROPORCIONADA_MODULO",
    "TT_FALLIDO",
    "ARCHIVADA",
}
FORBIDDEN_FUNCTIONS = {"LOCAL", "SUPERIOR", "ESTRUCTURA", "GIRO", "B_EXCESIVA", "OBSERVADOR"}


def price_i(value: float | int | str) -> int:
    return int(round(float(value) * PRICE_SCALE))


def price_s(value: int | float | None) -> str:
    if value is None:
        return ""
    return f"{int(value) / PRICE_SCALE:.2f}"


def ms_to_text(ms: int | None) -> str:
    if ms is None:
        return ""
    dt = datetime.fromtimestamp(ms / 1000, timezone.utc)
    return dt.strftime("%Y-%m-%d %H:%M:%S.") + f"{dt.microsecond // 1000:03d}"


def ms_to_hms(ms: int | None) -> str:
    if ms is None:
        return ""
    dt = datetime.fromtimestamp(ms / 1000, timezone.utc)
    return dt.strftime("%H:%M:%S.") + f"{dt.microsecond // 1000:03d}"


def parse_hms(value: str | int | None, base_ms: int | None = None) -> int | None:
    if value is None or value == "":
        return None
    if isinstance(value, int):
        return value
    text = str(value).strip()
    if text.isdigit():
        return int(text)
    parts = text.split(":")
    if len(parts) < 2:
        raise ValueError(f"hora inválida: {value!r}")
    hour = int(parts[0])
    minute = int(parts[1])
    second = 0
    milli = 0
    if len(parts) >= 3:
        sec_part = parts[2]
        if "." in sec_part:
            sec_text, frac = sec_part.split(".", 1)
            second = int(sec_text)
            milli = int((frac + "000")[:3])
        else:
            second = int(sec_part)
    if base_ms is None:
        now = datetime.now(timezone.utc)
        base = now.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        base = datetime.fromtimestamp(base_ms / 1000, timezone.utc)
    target = base.replace(hour=hour, minute=minute, second=second, microsecond=milli * 1000)
    return int(target.timestamp() * 1000)


@dataclass(frozen=True)
class Pt:
    price: int
    seq: int
    time_ms: int
    bar: int

    @property
    def hms(self) -> str:
        return ms_to_hms(self.time_ms)


@dataclass
class Bar:
    idx: int
    name: str
    open: Pt
    high: Pt
    low: Pt
    last: Pt
    prev_close: Optional[int] = None
    gap: int = 0


@dataclass(frozen=True)
class Movement:
    origin: int
    extreme: int
    direction: int
    origin_index: int
    extreme_index: int
    confirm_index: int

    @property
    def size(self) -> int:
        return abs(self.extreme - self.origin)


@dataclass
class Reading:
    reading_id: str
    direction: int
    state: str
    created_time: int
    created_seq: int
    created_bar: int
    origin_reason: str
    module_origin: int
    module_extreme: int
    module_origin_time: int
    module_extreme_time: int
    module_origin_seq: int
    module_extreme_seq: int
    parent_reading_id: str = ""
    closed_time: int | None = None
    closed_bar: int | None = None
    a_origin: int = 0
    a_end: int = 0
    a_origin_time: int = 0
    a_end_time: int = 0
    a_origin_seq: int = 0
    a_end_seq: int = 0
    a_knowledge_time: int = 0
    b_origin: int = 0
    b_extreme: int = 0
    b_origin_time: int = 0
    b_extreme_time: int = 0
    b_origin_seq: int = 0
    b_extreme_seq: int = 0
    b_knowledge_time: int = 0
    c_origin: int = 0
    c_extreme: int = 0
    c_origin_time: int = 0
    c_extreme_time: int = 0
    c_knowledge_time: int = 0
    aut_time: int = 0
    aut_price: int = 0
    tt_target: int = 0
    tt_hit: bool = False
    tt_time: int = 0
    tt_price: int = 0
    tt_seq: int = 0
    tt_confirmation_time: int = 0
    tt_knowledge_time: int = 0
    tt_extreme: int = 0
    tt_extreme_time: int = 0
    tt_extreme_seq: int = 0
    b_grande_time: int = 0
    aut_reclassified: bool = False
    ft: bool = False
    ft_time: int = 0
    ft_price: int = 0
    ft_structural_time: int = 0
    fail_reason: str = ""
    fail_time: int = 0
    fail_price: int = 0
    a_sig_opened: bool = False
    labels: list[tuple[int, str]] = field(default_factory=list)
    leg_indices: list[int] = field(default_factory=list)
    structural_valid: bool = True
    operational_valid: bool = False
    operational_rejection_reason: str = "FASE1_SOLO_LECTURA"
    post_tt: bool = False
    parent_tt_id: str = ""
    generation: int = 1

    @property
    def module_size(self) -> int:
        return abs(self.module_extreme - self.module_origin)

    @property
    def a_size(self) -> int:
        if not self.a_origin or not self.a_end:
            return 0
        return abs(self.a_end - self.a_origin)

    @property
    def b_size(self) -> int:
        if not self.b_origin or not self.b_extreme:
            return 0
        return abs(self.b_extreme - self.b_origin)

    @property
    def c_size(self) -> int:
        if not self.c_origin or not self.c_extreme:
            return 0
        return abs(self.c_extreme - self.c_origin)

    @property
    def x_size(self) -> int:
        return self.module_size

    @property
    def tt_pt(self) -> Pt | None:
        if not self.tt_hit:
            return None
        return Pt(self.tt_price, self.tt_seq, self.tt_time, self.tt_time // 60000)


def load_feed(path: Path | str) -> tuple[list[Pt], dict[int, Bar]]:
    path = Path(path)
    with path.open(encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh, delimiter=";")
        required = {"sequence_id", "time_msc", "bid"}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"feed missing columns: {sorted(missing)}")
        rows = list(reader)
    points: list[Pt] = []
    seen: set[int] = set()
    last_time = -1
    for row in sorted(rows, key=lambda item: int(item["sequence_id"])):
        seq = int(row["sequence_id"])
        if seq in seen:
            raise ValueError(f"duplicate sequence_id: {seq}")
        seen.add(seq)
        ts = int(row["time_msc"])
        if ts < last_time:
            raise ValueError("time moves backwards after sequence_id ordering")
        last_time = ts
        points.append(Pt(price_i(row["bid"]), seq, ts, ts // 60000))
    bars: dict[int, Bar] = {}
    for p in points:
        bar = bars.get(p.bar)
        if bar is None:
            prev = bars[max(bars)].last.price if bars else None
            gap = p.price - prev if prev is not None else 0
            bars[p.bar] = Bar(p.bar, ms_to_hms(p.bar * 60000)[:5], p, p, p, p, prev, gap)
        else:
            if p.price > bar.high.price:
                bar.high = p
            if p.price < bar.low.price:
                bar.low = p
            bar.last = p
    return points, bars


def filter_points(points: list[Pt], start: int | None = None, end: int | None = None) -> list[Pt]:
    result = points
    if start is not None:
        result = [p for p in result if p.time_ms >= start]
    if end is not None:
        result = [p for p in result if p.time_ms <= end]
    return result


class MovementBuilder:
    def __init__(
        self,
        first: Pt,
        min_move: int = MOVE,
        retrace_num: int = RETRACE_NUM,
        retrace_den: int = RETRACE_DEN,
    ) -> None:
        self.min_move = min_move
        self.retrace_num = retrace_num
        self.retrace_den = retrace_den
        self.origin = first.price
        self.ext = first.price
        self.direction = 0
        self.origin_index = 0
        self.extreme_index = 0
        self.index = 0

    def feed(self, p: Pt, index: int) -> Movement | None:
        self.index = index
        if self.direction == 0:
            if p.price - self.origin >= self.min_move:
                self.direction = 1
                self.ext = p.price
                self.extreme_index = index
            elif self.origin - p.price >= self.min_move:
                self.direction = -1
                self.ext = p.price
                self.extreme_index = index
            return None
        threshold = max(self.min_move, (abs(self.ext - self.origin) * self.retrace_num) // self.retrace_den)
        if self.direction > 0:
            if p.price > self.ext:
                self.ext = p.price
                self.extreme_index = index
                return None
            if self.ext - p.price >= threshold:
                movement = Movement(self.origin, self.ext, 1, self.origin_index, self.extreme_index, index)
                self._reanchor(p, index, -1)
                return movement
        else:
            if p.price < self.ext:
                self.ext = p.price
                self.extreme_index = index
                return None
            if p.price - self.ext >= threshold:
                movement = Movement(self.origin, self.ext, -1, self.origin_index, self.extreme_index, index)
                self._reanchor(p, index, 1)
                return movement
        return None

    def _reanchor(self, p: Pt, index: int, direction: int) -> None:
        self.origin = self.ext
        self.origin_index = self.extreme_index
        self.ext = p.price
        self.extreme_index = index
        self.direction = direction


def build_movements(
    points: list[Pt],
    min_move: int = MOVE,
    retrace_num: int = RETRACE_NUM,
    retrace_den: int = RETRACE_DEN,
) -> list[Movement]:
    if not points:
        return []
    builder = MovementBuilder(points[0], min_move, retrace_num, retrace_den)
    movements: list[Movement] = []
    for i, p in enumerate(points[1:], 1):
        movement = builder.feed(p, i)
        if movement is not None:
            movements.append(movement)
    return movements


class TickScheduler:
    """Ordena tareas por tiempo/seq de conocimiento; no altera la verdad estructural."""

    def __init__(self) -> None:
        self.tasks: list[dict[str, Any]] = []
        self._task_seq = 0

    def schedule(
        self,
        name: str,
        due_pt: Pt,
        callback: Callable[[], None],
        priority: int = 50,
        *,
        scheduled_at: Pt | None = None,
    ) -> None:
        now = scheduled_at or due_pt
        if due_pt.time_ms < now.time_ms or due_pt.seq < now.seq:
            raise ValueError("scheduler task cannot be scheduled in the past")
        self._task_seq += 1
        self.tasks.append(
            {
                "task_id": self._task_seq,
                "name": name,
                "due_time": due_pt.time_ms,
                "due_seq": due_pt.seq,
                "scheduled_time": now.time_ms,
                "scheduled_seq": now.seq,
                "priority": priority,
                "callback": callback,
            }
        )

    def run_due(self, pt: Pt) -> list[dict[str, Any]]:
        due = [
            task
            for task in self.tasks
            if task["due_time"] <= pt.time_ms and task["due_seq"] <= pt.seq
        ]
        due.sort(key=lambda task: (task["due_time"], task["due_seq"], task["priority"], task["task_id"]))
        done: list[dict[str, Any]] = []
        for task in due:
            self.tasks.remove(task)
            task["callback"]()
            done.append(task)
        return done

    def pending(self) -> list[dict[str, Any]]:
        return list(self.tasks)


class Engine:
    def __init__(self, points: list[Pt], bars: dict[int, Bar]):
        self.points = points
        self.bars = bars
        self.movements: list[Movement] = []
        self.readings: list[Reading] = []
        self.events: list[dict] = []
        self.patterns: list[dict] = []
        self.audit: list[dict] = []
        self.knowledge_audit: list[dict] = []
        self.narrative: list[dict] = []
        self.pending: list[str] = []
        self.coverage: dict = {}
        self.active: list[Reading] = []
        self.by_id: dict[str, Reading] = {}
        self.scheduler = TickScheduler()
        self.builder = MovementBuilder(points[0]) if points else None
        self.afs2: dict = {}
        self._reading_seq = 0
        self._event_seq = 0
        self._pattern_seq = 0
        self._last_bar: int | None = None
        self._prev_price: int | None = None
        self._tick_before: dict[str, str] = {}
        self._current_pt: Pt | None = None
        self.start_time = points[0].time_ms if points else 0
        self.end_time = points[-1].time_ms if points else 0

    def active_at(self, time_ms: int) -> list[Reading]:
        return [
            r
            for r in self.readings
            if r.created_time <= time_ms and (r.closed_time is None or r.closed_time > time_ms)
        ]

    def _next_reading_id(self) -> str:
        self._reading_seq += 1
        return f"R{self._reading_seq:04d}"

    def _emit(
        self,
        kind: str,
        knowledge_pt: Pt,
        reading: Reading | None,
        function: str,
        new_state: str,
        reason: str = "",
        detail: str = "",
        *,
        structural_pt: Pt | None = None,
        confirmation_pt: Pt | None = None,
    ) -> dict:
        self._event_seq += 1
        sp = structural_pt or knowledge_pt
        cp = confirmation_pt or knowledge_pt
        event = {
            "event_id": f"E{self._event_seq:06d}",
            "sequence_id": knowledge_pt.seq,
            "knowledge_sequence_id": knowledge_pt.seq,
            "structural_sequence_id": sp.seq,
            "confirmation_sequence_id": cp.seq,
            "time_ms": knowledge_pt.time_ms,
            "time": ms_to_text(knowledge_pt.time_ms),
            "knowledge_time_ms": knowledge_pt.time_ms,
            "knowledge_time": ms_to_text(knowledge_pt.time_ms),
            "structural_time_ms": sp.time_ms,
            "structural_time": ms_to_text(sp.time_ms),
            "confirmation_time_ms": cp.time_ms,
            "confirmation_time": ms_to_text(cp.time_ms),
            "bar": knowledge_pt.bar,
            "bar_time": ms_to_hms(knowledge_pt.bar * 60000)[:5],
            "structural_bar": sp.bar,
            "price": sp.price,
            "knowledge_price": knowledge_pt.price,
            "gap": self.bars.get(knowledge_pt.bar).gap if knowledge_pt.bar in self.bars else 0,
            "kind": kind,
            "function": function,
            "new_state": new_state,
            "reading_id": reading.reading_id if reading else "",
            "parent_reading_id": reading.parent_reading_id if reading else "",
            "direction": reading.direction if reading else 0,
            "module_origin": reading.module_origin if reading else 0,
            "module_extreme": reading.module_extreme if reading else 0,
            "module_size": reading.module_size if reading else 0,
            "a_origin": reading.a_origin if reading else 0,
            "a_end": reading.a_end if reading else 0,
            "a_size": reading.a_size if reading else 0,
            "b_origin": reading.b_origin if reading else 0,
            "b_extreme": reading.b_extreme if reading else 0,
            "b_size": reading.b_size if reading else 0,
            "c_origin": reading.c_origin if reading else 0,
            "c_extreme": reading.c_extreme if reading else 0,
            "c_size": reading.c_size if reading else 0,
            "tt_target": reading.tt_target if reading else 0,
            "tt_100": reading.tt_price if reading and reading.tt_hit else 0,
            "tt_real_extreme": reading.tt_extreme if reading else 0,
            "ft": int(reading.ft) if reading else 0,
            "structural_valid": int(reading.structural_valid) if reading else 1,
            "operational_valid": int(reading.operational_valid) if reading else 0,
            "operational_rejection_reason": reading.operational_rejection_reason if reading else "",
            "reason": reason,
            "detail": detail,
        }
        if event["knowledge_time_ms"] < event["confirmation_time_ms"]:
            raise AssertionError(f"event {event['event_id']} known before confirmation")
        self.events.append(event)
        return event

    def _pattern(
        self,
        pattern_type: str,
        status: str,
        reading: Reading | None,
        origin: int,
        end: int,
        detail: str = "",
        time_ms: int | None = None,
    ) -> dict:
        self._pattern_seq += 1
        pattern = {
            "pattern_id": f"P{self._pattern_seq:04d}",
            "type": pattern_type,
            "status": status,
            "final_status": status,
            "direction": reading.direction if reading else 0,
            "origin_time": ms_to_text(reading.module_origin_time if reading else time_ms),
            "origin_price": origin,
            "end_time": ms_to_text(time_ms if time_ms is not None else (reading.closed_time if reading else None)),
            "end_price": end,
            "size": abs(end - origin),
            "reading_id": reading.reading_id if reading else "",
            "cycle_id": reading.reading_id if reading else "",
            "detail": detail,
        }
        self.patterns.append(pattern)
        return pattern

    def _create_reading(
        self,
        pt: Pt,
        reason: str,
        parent: Reading | None,
        direction: int,
        origin: int,
        ext: int,
        origin_time: int,
        ext_time: int,
        origin_seq: int,
        ext_seq: int,
        leg_index: int,
    ) -> Reading:
        reading = Reading(
            reading_id=self._next_reading_id(),
            direction=direction,
            state="MODULE",
            created_time=pt.time_ms,
            created_seq=pt.seq,
            created_bar=pt.bar,
            origin_reason=reason,
            module_origin=origin,
            module_extreme=ext,
            module_origin_time=origin_time,
            module_extreme_time=ext_time,
            module_origin_seq=origin_seq,
            module_extreme_seq=ext_seq,
            parent_reading_id=parent.reading_id if parent else "",
        )
        reading.labels.append((leg_index, "1"))
        reading.leg_indices.append(leg_index)
        self.readings.append(reading)
        self.by_id[reading.reading_id] = reading
        self.active.append(reading)
        self._pattern("LECTURA_FUNCIONAL", "ACTIVA", reading, origin, ext, reason)
        self._emit("LECTURA_CREADA", pt, reading, "1", "MODULE", reason)
        return reading

    def _done(self, r: Reading, pt: Pt, state: str = "DONE", reason: str = "") -> None:
        if r.state == "DONE":
            return
        r.state = state
        r.closed_time = pt.time_ms
        r.closed_bar = pt.bar
        if reason:
            r.fail_reason = reason

    def _aut_limit(self, r: Reading) -> int:
        return (AUT_NUM * r.a_size) // AUT_DEN + AUT_EXTRA

    def _maybe_aut(self, r: Reading, pt: Pt, ep: Pt, movement: Movement) -> None:
        if r.aut_reclassified or r.b_size <= self._aut_limit(r):
            return
        r.aut_time = pt.time_ms
        r.aut_price = ep.price
        r.aut_reclassified = True
        r.labels.append((movement.confirm_index, "AUT"))
        self._emit(
            "AUT",
            pt,
            r,
            "AUT",
            "AUT",
            "SUPERA_127_MAS_025",
            structural_pt=ep,
            confirmation_pt=pt,
        )
        self._pattern("AUT", "CONFIRMADO", r, r.b_origin, r.b_extreme, "B_SUPERA_AUT", pt.time_ms)

    def _b_grande(self, r: Reading, pt: Pt, ep: Pt, movement: Movement) -> None:
        r.b_extreme = movement.extreme
        r.b_extreme_time = ep.time_ms
        r.b_extreme_seq = ep.seq
        r.b_grande_time = pt.time_ms
        r.b_knowledge_time = pt.time_ms
        r.tt_target = r.a_end + r.direction * r.module_size
        r.state = "TT_PENDING"
        r.labels.append((movement.confirm_index, "B_GRANDE"))
        self._emit(
            "B_GRANDE",
            pt,
            r,
            "B_GRANDE",
            "TT_PENDING",
            "B_100_A",
            structural_pt=ep,
            confirmation_pt=pt,
        )
        self._pattern("B_GRANDE", "CONFIRMADO", r, r.b_origin, r.b_extreme, "B>=A", pt.time_ms)
        self._maybe_aut(r, pt, ep, movement)
        self._check_tt(r, movement, pt)

    def _check_tt(self, r: Reading, movement: Movement, knowledge_pt: Pt) -> None:
        if not r.tt_target or r.tt_hit or not r.b_grande_time:
            return
        for i in range(movement.origin_index, movement.extreme_index + 1):
            p = self.points[i]
            if (r.direction > 0 and p.price >= r.tt_target) or (r.direction < 0 and p.price <= r.tt_target):
                r.tt_hit = True
                r.tt_time = p.time_ms
                r.tt_price = p.price
                r.tt_seq = p.seq
                r.tt_confirmation_time = knowledge_pt.time_ms
                r.tt_knowledge_time = knowledge_pt.time_ms
                r.tt_extreme = movement.extreme
                r.tt_extreme_time = self.points[movement.extreme_index].time_ms
                r.tt_extreme_seq = self.points[movement.extreme_index].seq
                r.state = "TT_EXT"
                r.labels.append((movement.confirm_index, "TT"))
                r.operational_valid = True
                r.operational_rejection_reason = ""
                self._emit(
                    "TT_100",
                    knowledge_pt,
                    r,
                    "TT",
                    "TT_EXT",
                    "TT_100",
                    f"target={price_s(r.tt_target)}",
                    structural_pt=p,
                    confirmation_pt=knowledge_pt,
                )
                self._pattern("TT", "CONFIRMADO", r, r.a_end, p.price, "TT_100", p.time_ms)
                return

    def _update(self, r: Reading, movement: Movement) -> None:
        if r.state == "DONE":
            return
        cp = self.points[movement.confirm_index]
        ep = self.points[movement.extreme_index]
        if r.state == "MODULE":
            if movement.direction == r.direction:
                r.module_extreme = movement.extreme
                r.module_extreme_time = ep.time_ms
                r.module_extreme_seq = ep.seq
                r.labels.append((movement.confirm_index, "1"))
                self._emit(
                    "MODULO_EXT",
                    cp,
                    r,
                    "1",
                    "MODULE",
                    "NUEVO_EXTREMO",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
            else:
                r.a_origin = r.module_extreme
                r.a_origin_time = r.module_extreme_time
                r.a_origin_seq = r.module_extreme_seq
                r.a_end = movement.extreme
                r.a_end_time = ep.time_ms
                r.a_end_seq = ep.seq
                r.a_knowledge_time = cp.time_ms
                r.state = "A"
                r.labels.append((movement.confirm_index, "A"))
                self._emit(
                    "A_INICIO",
                    cp,
                    r,
                    "A",
                    "A",
                    "MOVIMIENTO_CONTRARIO",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
            return
        if r.state == "A":
            if movement.direction == r.direction:
                r.b_origin = r.a_end
                r.b_origin_time = r.a_end_time
                r.b_origin_seq = r.a_end_seq
                r.b_extreme = movement.extreme
                r.b_extreme_time = ep.time_ms
                r.b_extreme_seq = ep.seq
                r.b_knowledge_time = cp.time_ms
                r.labels.append((movement.confirm_index, "B"))
                self._emit(
                    "B_INICIO",
                    cp,
                    r,
                    "B",
                    "B",
                    "CONTRARIO_A_A",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
                if r.b_size >= r.a_size:
                    self._b_grande(r, cp, ep, movement)
                else:
                    r.state = "B_CAND"
            else:
                if r.direction > 0:
                    r.a_end = min(r.a_end, movement.extreme)
                else:
                    r.a_end = max(r.a_end, movement.extreme)
                r.a_end_time = ep.time_ms
                r.a_end_seq = ep.seq
                r.a_knowledge_time = cp.time_ms
                r.labels.append((movement.confirm_index, "A"))
                self._emit(
                    "A_EXT",
                    cp,
                    r,
                    "A",
                    "A",
                    "A_CONTINUA",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
            return
        if r.state == "B_CAND":
            if movement.direction == r.direction:
                r.b_extreme = movement.extreme
                r.b_extreme_time = ep.time_ms
                r.b_extreme_seq = ep.seq
                r.b_knowledge_time = cp.time_ms
                r.labels.append((movement.confirm_index, "B"))
                self._emit(
                    "B_EXT",
                    cp,
                    r,
                    "B",
                    "B_CAND",
                    "B_CONTINUA",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
                if r.b_size >= r.a_size:
                    self._b_grande(r, cp, ep, movement)
            else:
                crosses = (r.direction > 0 and movement.extreme <= r.a_end) or (
                    r.direction < 0 and movement.extreme >= r.a_end
                )
                if crosses:
                    if r.direction > 0:
                        r.a_end = min(r.a_end, movement.extreme)
                    else:
                        r.a_end = max(r.a_end, movement.extreme)
                    r.a_end_time = ep.time_ms
                    r.a_end_seq = ep.seq
                    r.a_knowledge_time = cp.time_ms
                    r.state = "A"
                    r.labels.append((movement.confirm_index, "B_FALLIDA"))
                    r.labels.append((movement.confirm_index, "A"))
                    self._emit(
                        "B_FALLIDA",
                        cp,
                        r,
                        "B_FALLIDA",
                        "A",
                        "B_NO_LLEGO_A_100",
                        structural_pt=ep,
                        confirmation_pt=cp,
                    )
                else:
                    r.labels.append((movement.confirm_index, "B_OSCILACION"))
                    self._emit(
                        "B_OSCILACION",
                        cp,
                        r,
                        "B_OSCILACION",
                        "B_CAND",
                        "OSCILACION_INTERNA",
                        structural_pt=ep,
                        confirmation_pt=cp,
                    )
            return
        if r.state == "TT_PENDING":
            if movement.direction == r.direction:
                old_b = r.b_extreme
                r.b_extreme = movement.extreme
                r.b_extreme_time = ep.time_ms
                r.b_extreme_seq = ep.seq
                if r.c_origin:
                    self._emit(
                        "C_CANCELADA",
                        cp,
                        r,
                        "C_CANCELADA",
                        "TT_PENDING",
                        "B_NUEVO_EXTREMO",
                        structural_pt=ep,
                        confirmation_pt=cp,
                    )
                    r.c_origin = 0
                    r.c_extreme = 0
                if old_b != r.b_extreme:
                    r.labels.append((movement.confirm_index, "B"))
                    self._emit(
                        "B_EXT",
                        cp,
                        r,
                        "B",
                        "TT_PENDING",
                        "B_CONTINUA",
                        structural_pt=ep,
                        confirmation_pt=cp,
                    )
                self._maybe_aut(r, cp, ep, movement)
                self._check_tt(r, movement, cp)
            else:
                r.c_origin = r.b_extreme
                r.c_origin_time = r.b_extreme_time
                r.c_extreme = movement.extreme
                r.c_extreme_time = ep.time_ms
                r.c_knowledge_time = cp.time_ms
                r.labels.append((movement.confirm_index, "C"))
                self._emit(
                    "C",
                    cp,
                    r,
                    "C",
                    "TT_PENDING",
                    "CONTRARIO_A_B",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
                if (r.direction > 0 and movement.extreme <= r.a_end - CUT_BUFFER) or (
                    r.direction < 0 and movement.extreme >= r.a_end + CUT_BUFFER
                ):
                    r.state = "DONE"
                    r.closed_time = cp.time_ms
                    r.closed_bar = cp.bar
                    r.fail_reason = "CUT_CRUZA_A_END_MAS_2"
                    r.labels.append((movement.confirm_index, "TT_FALLIDO"))
                    r.labels.append((movement.confirm_index, "CUT"))
                    self._emit(
                        "CUT",
                        cp,
                        r,
                        "CUT",
                        "DONE",
                        "CUT_CRUZA_A_END_MAS_2",
                        structural_pt=ep,
                        confirmation_pt=cp,
                    )
                    self._pattern("CUT", "CONFIRMADO", r, r.c_origin, r.c_extreme, r.fail_reason, cp.time_ms)
            return
        if r.state == "TT_EXT":
            if movement.direction == r.direction:
                r.tt_extreme = movement.extreme
                r.tt_extreme_time = ep.time_ms
                r.tt_extreme_seq = ep.seq
                self._emit(
                    "TT_EXT",
                    cp,
                    r,
                    "TT",
                    "TT_EXT",
                    "TT_EXTIENDE",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
            else:
                r.ft = True
                r.ft_time = cp.time_ms
                r.ft_price = movement.extreme
                r.ft_structural_time = ep.time_ms
                r.state = "DONE"
                r.closed_time = cp.time_ms
                r.closed_bar = cp.bar
                r.labels.append((movement.confirm_index, "FT"))
                self._emit(
                    "FT",
                    cp,
                    r,
                    "FT",
                    "DONE",
                    "CONTRARIO_DESPUES_DE_TT",
                    structural_pt=ep,
                    confirmation_pt=cp,
                )
                self._pattern("FT", "CONFIRMADO", r, r.tt_extreme, movement.extreme, "FT", cp.time_ms)

    def _open_candidate(
        self,
        movement: Movement,
        snapshots: list[tuple[Reading, str, int, int, int, int, bool]],
    ) -> tuple[str, Reading | None, int, int, int, int, int, int] | None:
        if not self.active:
            p = self.points[movement.origin_index]
            e = self.points[movement.extreme_index]
            return (
                "FIRST",
                None,
                movement.direction,
                movement.origin,
                movement.extreme,
                p.time_ms,
                e.time_ms,
                p.seq,
                e.seq,
            )
        for r, state, a_size, x_size, direction, a_end, a_sig in snapshots:
            if r.state == "DONE":
                continue
            if state == "TT_EXT" and movement.direction != direction:
                p = self.points[movement.origin_index]
                e = self.points[movement.extreme_index]
                return (
                    "FT_NEW1",
                    r,
                    movement.direction,
                    movement.origin,
                    movement.extreme,
                    p.time_ms,
                    e.time_ms,
                    p.seq,
                    e.seq,
                )
        for r, state, a_size, x_size, direction, a_end, a_sig in snapshots:
            if r.state == "DONE":
                continue
            if state == "A" and movement.direction == direction and movement.size >= a_size and movement.size >= MOVE:
                p = self.points[movement.origin_index]
                e = self.points[movement.extreme_index]
                return (
                    "B_CONFIRMADA_NEW1",
                    r,
                    movement.direction,
                    movement.origin,
                    movement.extreme,
                    p.time_ms,
                    e.time_ms,
                    p.seq,
                    e.seq,
                )
        for r, state, a_size, x_size, direction, a_end, a_sig in snapshots:
            if r.state == "DONE":
                continue
            if (
                state in ("MODULE", "A", "B_CAND")
                and movement.direction != direction
                and x_size >= MIN_MODULE
                and a_size * A_SIGNIFICANT_DEN >= x_size * A_SIGNIFICANT_NUM
                and not a_sig
            ):
                return (
                    "A_SIGNIFICATIVA",
                    r,
                    -direction,
                    r.a_origin,
                    r.a_end,
                    r.a_origin_time,
                    r.a_end_time,
                    r.a_origin_seq,
                    r.a_end_seq,
                )
        for r, state, a_size, x_size, direction, a_end, a_sig in snapshots:
            if r.state == "DONE":
                continue
            if state == "TT_PENDING" and movement.direction != direction:
                cut = (direction > 0 and movement.extreme <= a_end - CUT_BUFFER) or (
                    direction < 0 and movement.extreme >= a_end + CUT_BUFFER
                )
                if cut:
                    p = self.points[movement.origin_index]
                    e = self.points[movement.extreme_index]
                    return (
                        "CUT_NEW1",
                        r,
                        movement.direction,
                        movement.origin,
                        movement.extreme,
                        p.time_ms,
                        e.time_ms,
                        p.seq,
                        e.seq,
                    )
        return None

    def _process_movement(self, movement: Movement) -> None:
        cp = self.points[movement.confirm_index]
        snapshots = [
            (r, r.state, r.a_size, r.x_size, r.direction, r.a_end, r.a_sig_opened)
            for r in list(self.active)
            if r.state != "DONE"
        ]
        for r in list(self.active):
            self._update(r, movement)
        self.active = [r for r in self.active if r.state != "DONE"]
        candidate = self._open_candidate(movement, snapshots)
        if candidate is not None:
            reason, parent, direction, origin, ext, origin_time, ext_time, origin_seq, ext_seq = candidate
            reading = self._create_reading(
                cp,
                reason,
                parent,
                direction,
                origin,
                ext,
                origin_time,
                ext_time,
                origin_seq,
                ext_seq,
                movement.confirm_index,
            )
            if parent is not None and reason == "A_SIGNIFICATIVA":
                parent.a_sig_opened = True
            if len(self.active) > MAX_ACTIVE:
                keep = {r.reading_id for r in sorted(self.active, key=lambda item: (-item.x_size, -item.created_time))[:MAX_ACTIVE]}
                for old in list(self.active):
                    if old.reading_id not in keep:
                        self._done(old, cp, "DONE", "ARCHIVADA_POR_CAPACIDAD")
                        old.labels.append((movement.confirm_index, "ARCHIVADA"))
                        self._emit("ARCHIVADA", cp, old, "ARCHIVADA", "DONE", "MAX_3_ACTIVAS")
                        if old in self.active:
                            self.active.remove(old)
        for r in list(self.active):
            if r.a_sig_opened and r.a_size > A_MAX_MODULE_MULTIPLE * r.x_size:
                self._done(r, cp, "DONE", "A_DESPROPORCIONADA_MODULO")
                r.labels.append((movement.confirm_index, "A_DESPROPORCIONADA_MODULO"))
                self._emit("A_DESPROPORCIONADA_MODULO", cp, r, "A_DESPROPORCIONADA_MODULO", "DONE", "A_MAYOR_2X_MODULO")
                if r in self.active:
                    self.active.remove(r)

    def _schedule_gap(self, p: Pt) -> None:
        bar = self.bars.get(p.bar)
        if bar is None or not bar.gap:
            return

        def emit_gap() -> None:
            self._emit(
                "GAP",
                p,
                None,
                "GAP",
                "GAP",
                f"gap={price_s(bar.gap)}",
                f"gap={price_s(bar.gap)}",
                structural_pt=p,
                confirmation_pt=p,
            )

        self.scheduler.schedule("GAP", p, emit_gap, priority=0, scheduled_at=p)

    def _owner(self, p: Pt) -> tuple[Reading | None, str, int]:
        candidates: list[tuple[int, int, str, Reading, str]] = []
        for r in self.active:
            if r.state == "DONE":
                continue
            source = ""
            if r.c_origin and r.c_extreme and min(r.c_origin, r.c_extreme) <= p.price <= max(r.c_origin, r.c_extreme):
                source = "C"
            elif r.b_origin and r.b_extreme and min(r.b_origin, r.b_extreme) <= p.price <= max(r.b_origin, r.b_extreme):
                source = "B"
            elif r.a_origin and r.a_end and min(r.a_origin, r.a_end) <= p.price <= max(r.a_origin, r.a_end):
                source = "A"
            elif min(r.module_origin, r.module_extreme) <= p.price <= max(r.module_origin, r.module_extreme):
                source = "MODULE"
            if source:
                candidates.append((r.module_size, r.created_time, r.reading_id, r, source))
        if not candidates:
            if self._prev_price is not None and abs(p.price - self._prev_price) < STRUCTURAL_MOVE:
                return None, "NOISE", 0
            return None, "NONE", 0
        candidates.sort(key=lambda item: (-item[0], item[1], item[2]))
        _, _, _, owner, source = candidates[0]
        return owner, source, len(candidates)

    def _record_knowledge(self, p: Pt) -> None:
        events_here = [event for event in self.events if event["knowledge_sequence_id"] == p.seq]
        owner, source, ownership = self._owner(p)
        active_ids = [r.reading_id for r in self.active if r.state != "DONE"]
        inherited = [rid for rid in active_ids if self.by_id[rid].created_bar < p.bar]
        local = [rid for rid in active_ids if self.by_id[rid].created_bar == p.bar]
        after = {r.reading_id: r.state for r in self.active if r.state != "DONE"}
        self.knowledge_audit.append(
            {
                "sequence_id": p.seq,
                "time": ms_to_text(p.time_ms),
                "time_ms": p.time_ms,
                "price": p.price,
                "bar_time": ms_to_hms(p.bar * 60000)[:5],
                "gap": self.bars[p.bar].gap if p.bar in self.bars else 0,
                "local_direction": ("UP" if owner.direction > 0 else "DOWN") if owner else "",
                "structural_origin": owner.module_origin if owner else 0,
                "structural_extreme": owner.module_extreme if owner else 0,
                "excursion": abs(p.price - owner.module_origin) if owner else 0,
                "owner_reading_id": owner.reading_id if owner else "",
                "owner_source": source,
                "owner_created_time": ms_to_text(owner.created_time) if owner else "",
                "owner_known_at_seq": owner.created_seq if owner else 0,
                "ownership_count": ownership,
                "functional_coverage": "OK" if owner or source == "NOISE" else "UNCOVERED",
                "active_readings": ";".join(active_ids),
                "inherited_readings": ";".join(inherited),
                "local_readings": ";".join(local),
                "functions_before": ";".join(f"{rid}:{st}" for rid, st in sorted(self._tick_before.items())),
                "functions_after": ";".join(f"{rid}:{st}" for rid, st in sorted(after.items())),
                "events_emitted": ";".join(event["event_id"] for event in events_here),
                "readings_created": ";".join(
                    event["reading_id"] for event in events_here if event["kind"] == "LECTURA_CREADA"
                ),
                "patterns_updated": ";".join(event["function"] for event in events_here if event["function"]),
                "decision_reason": ";".join(event["reason"] for event in events_here if event["reason"]) or "NO_ACTION",
            }
        )

    def run(self) -> "Engine":
        for index, p in enumerate(self.points):
            self._current_pt = p
            self._tick_before = {r.reading_id: r.state for r in self.active if r.state != "DONE"}
            if self._last_bar is None or p.bar != self._last_bar:
                self._schedule_gap(p)
            self.scheduler.run_due(p)
            if index:
                movement = self.builder.feed(p, index) if self.builder is not None else None
                if movement is not None:
                    self.movements.append(movement)
                    self._process_movement(movement)
            self._record_knowledge(p)
            self._prev_price = p.price
            self._last_bar = p.bar
        last = self.points[-1] if self.points else Pt(0, 0, 0, 0)
        self._emit("FIN_FEED", last, None, "", "END", "END_OF_FEED", "fin del feed")
        self._finalize()
        return self

    def _finalize(self) -> None:
        self.coverage = evaluate_coverage(self)
        self.audit = build_audit(self)
        self.narrative = build_narrative(self)
        self.pending = [
            "post_tt_fallido_no_definido",
            "ft_expiracion_no_definida",
            "entrada_tardia_ft_no_definida",
            "a_mayor_que_modulo_guardia_provisional",
            "aut_extra_tick_unidad_cerrada_0_25",
            "cobertura_estructural_definicion_por_confirmar",
        ]
        if not self.coverage.get("causal_functional_ok", False):
            self.pending.append("functional_coverage_causal_parcial")
        if not self.coverage.get("causal_geometric_ok", False):
            self.pending.append("geometric_coverage_causal_parcial")
        for r in self.readings:
            if r.state != "DONE":
                self.pending.append(f"lectura_abierta_al_final:{r.reading_id}")
                break
        self.afs2 = evaluate_afs2(self, prefix_failures=None)


def structural_swings(points: list[Pt], threshold: int = STRUCTURAL_MOVE) -> list[dict]:
    if not points:
        return []
    origin = points[0]
    ext = origin
    direction = 0
    origin_index = extreme_index = 0
    swings: list[dict] = []
    for i, p in enumerate(points[1:], 1):
        if direction == 0:
            if p.price - origin.price >= threshold:
                direction = 1
                ext = p
                extreme_index = i
            elif origin.price - p.price >= threshold:
                direction = -1
                ext = p
                extreme_index = i
            continue
        if direction > 0:
            if p.price > ext.price:
                ext = p
                extreme_index = i
            elif ext.price - p.price >= threshold:
                swings.append(
                    {
                        "origin": origin.price,
                        "extreme": ext.price,
                        "direction": 1,
                        "size": ext.price - origin.price,
                        "origin_time": origin.time_ms,
                        "extreme_time": ext.time_ms,
                        "origin_seq": origin.seq,
                        "extreme_seq": ext.seq,
                        "confirm_time": p.time_ms,
                        "confirm_seq": p.seq,
                    }
                )
                origin = ext
                origin_index = extreme_index
                ext = p
                extreme_index = i
                direction = -1
        else:
            if p.price < ext.price:
                ext = p
                extreme_index = i
            elif p.price - ext.price >= threshold:
                swings.append(
                    {
                        "origin": origin.price,
                        "extreme": ext.price,
                        "direction": -1,
                        "size": origin.price - ext.price,
                        "origin_time": origin.time_ms,
                        "extreme_time": ext.time_ms,
                        "origin_seq": origin.seq,
                        "extreme_seq": ext.seq,
                        "confirm_time": p.time_ms,
                        "confirm_seq": p.seq,
                    }
                )
                origin = ext
                origin_index = extreme_index
                ext = p
                extreme_index = i
                direction = 1
    return swings


def _range_contains(reading: Reading, origin: int, extreme: int) -> bool:
    lo, hi = sorted((origin, extreme))
    ranges = [(reading.module_origin, reading.module_extreme)]
    if reading.a_origin and reading.a_end:
        ranges.append((reading.a_origin, reading.a_end))
    if reading.b_origin and reading.b_extreme:
        ranges.append((reading.b_origin, reading.b_extreme))
    if reading.c_origin and reading.c_extreme:
        ranges.append((reading.c_origin, reading.c_extreme))
    return any(min(a, b) <= lo and hi <= max(a, b) for a, b in ranges)


def _known_by(r: Reading, time_ms: int, seq: int) -> bool:
    return r.created_time <= time_ms and r.created_seq <= seq


def evaluate_coverage(engine: Engine) -> dict:
    swings = structural_swings(engine.points, STRUCTURAL_MOVE)
    geometric_uncovered: list[dict] = []
    functional_uncovered: list[dict] = []
    causal_geometric_uncovered: list[dict] = []
    causal_functional_uncovered: list[dict] = []
    for swing in swings:
        geometric = any(_range_contains(r, swing["origin"], swing["extreme"]) for r in engine.readings)
        functional = any(
            _range_contains(r, swing["origin"], swing["extreme"]) and r.a_origin
            for r in engine.readings
        )
        causal_geometric = any(
            _known_by(r, swing["confirm_time"], swing["confirm_seq"])
            and _range_contains(r, swing["origin"], swing["extreme"])
            for r in engine.readings
        )
        causal_functional = any(
            _known_by(r, swing["confirm_time"], swing["confirm_seq"])
            and r.a_knowledge_time
            and r.a_knowledge_time <= swing["confirm_time"]
            and _range_contains(r, swing["origin"], swing["extreme"])
            for r in engine.readings
        )
        if not geometric:
            geometric_uncovered.append(swing)
        if not functional:
            functional_uncovered.append(swing)
        if not causal_geometric:
            causal_geometric_uncovered.append(swing)
        if not causal_functional:
            causal_functional_uncovered.append(swing)
    movements = engine.movements
    functional_movements = 0
    causal_functional_movements = 0
    for m in movements:
        confirm = engine.points[m.confirm_index]
        if any(_range_contains(r, m.origin, m.extreme) and r.a_origin for r in engine.readings):
            functional_movements += 1
        if any(
            _known_by(r, confirm.time_ms, confirm.seq)
            and r.a_knowledge_time
            and r.a_knowledge_time <= confirm.time_ms
            and _range_contains(r, m.origin, m.extreme)
            for r in engine.readings
        ):
            causal_functional_movements += 1
    owner_rows = [row for row in engine.knowledge_audit if row["functional_coverage"] == "OK"]
    uncovered_rows = [row for row in engine.knowledge_audit if row["functional_coverage"] == "UNCOVERED"]
    return {
        "structural_swing_count": len(swings),
        "geometric_count": len(swings) - len(geometric_uncovered),
        "functional_count": len(swings) - len(functional_uncovered),
        "causal_geometric_count": len(swings) - len(causal_geometric_uncovered),
        "causal_functional_count": len(swings) - len(causal_functional_uncovered),
        "geometric_uncovered": geometric_uncovered,
        "functional_uncovered": functional_uncovered,
        "causal_geometric_uncovered": causal_geometric_uncovered,
        "causal_functional_uncovered": causal_functional_uncovered,
        "geometric_ok": not geometric_uncovered,
        "functional_ok": not functional_uncovered,
        "causal_geometric_ok": not causal_geometric_uncovered,
        "causal_functional_ok": not causal_functional_uncovered,
        "movement_count": len(movements),
        "functional_movement_count": functional_movements,
        "causal_functional_movement_count": causal_functional_movements,
        "movement_coverage_ok": functional_movements == len(movements),
        "causal_movement_coverage_ok": causal_functional_movements == len(movements),
        "tick_count": len(engine.knowledge_audit),
        "owner_tick_count": len(owner_rows),
        "noise_tick_count": sum(1 for row in engine.knowledge_audit if row["owner_source"] == "NOISE"),
        "uncovered_tick_count": len(uncovered_rows),
        "owner_coverage_ok": not uncovered_rows,
    }


def build_audit(engine: Engine) -> list[dict]:
    return list(engine.knowledge_audit)


def build_narrative(engine: Engine) -> list[dict]:
    rows: list[dict] = []
    for bar_idx in sorted(engine.bars):
        bar = engine.bars[bar_idx]
        start = bar_idx * 60000
        end = start + 59999
        bar_points = [p for p in engine.points if start <= p.time_ms <= end]
        if not bar_points:
            continue
        events = [e for e in engine.events if start <= e["time_ms"] <= end]
        started = [e["reading_id"] for e in events if e["kind"] == "LECTURA_CREADA"]
        closed = [
            e["reading_id"]
            for e in events
            if e["function"] in ("FT", "CUT", "TT_FALLIDO", "A_DESPROPORCIONADA_MODULO", "ARCHIVADA")
        ]
        audit_rows = [row for row in engine.knowledge_audit if row["bar_time"] == bar.name]
        close_row = audit_rows[-1] if audit_rows else {}
        active = close_row.get("active_readings", "").split(";") if close_row.get("active_readings") else []
        pending = [
            item.split(":", 1)[1]
            for item in close_row.get("functions_after", "").split(";")
            if ":" in item
        ]
        extreme_order = (
            f"L({ms_to_hms(bar.low.time_ms)},{price_s(bar.low.price)})"
            f";H({ms_to_hms(bar.high.time_ms)},{price_s(bar.high.price)})"
            if bar.low.time_ms <= bar.high.time_ms
            else f"H({ms_to_hms(bar.high.time_ms)},{price_s(bar.high.price)})"
            f";L({ms_to_hms(bar.low.time_ms)},{price_s(bar.low.price)})"
        )
        rows.append(
            {
                "bar_time": bar.name,
                "open": bar.open.price,
                "high": bar.high.price,
                "low": bar.low.price,
                "close": bar.last.price,
                "gap": bar.gap,
                "extreme_order": extreme_order,
                "functions": ";".join(e["function"] for e in events if e["function"]),
                "readings_started": ";".join(started),
                "readings_closed": ";".join(closed),
                "active_at_close": ";".join(active),
                "patterns": len([e for e in events if e["function"]]),
                "pending": ";".join(pending),
            }
        )
    return rows


EVENT_FIELDS = [
    "event_id",
    "sequence_id",
    "knowledge_sequence_id",
    "structural_sequence_id",
    "confirmation_sequence_id",
    "time",
    "time_ms",
    "knowledge_time",
    "knowledge_time_ms",
    "structural_time",
    "structural_time_ms",
    "confirmation_time",
    "confirmation_time_ms",
    "bar",
    "bar_time",
    "structural_bar",
    "price",
    "knowledge_price",
    "gap",
    "kind",
    "function",
    "new_state",
    "reading_id",
    "parent_reading_id",
    "direction",
    "module_origin",
    "module_extreme",
    "module_size",
    "a_origin",
    "a_end",
    "a_size",
    "b_origin",
    "b_extreme",
    "b_size",
    "c_origin",
    "c_extreme",
    "c_size",
    "tt_target",
    "tt_100",
    "tt_real_extreme",
    "ft",
    "structural_valid",
    "operational_valid",
    "operational_rejection_reason",
    "reason",
    "detail",
]

READING_FIELDS = [
    "reading_id",
    "direction",
    "state",
    "created_time",
    "created_seq",
    "created_bar",
    "closed_time",
    "parent_reading_id",
    "origin_reason",
    "module_origin",
    "module_extreme",
    "x",
    "a_origin",
    "a_end",
    "a",
    "b_origin",
    "b_extreme",
    "b",
    "c_origin",
    "c_extreme",
    "c",
    "aut_time",
    "aut_price",
    "tt_target",
    "tt_100_time",
    "tt_100_price",
    "tt_confirmation_time",
    "tt_knowledge_time",
    "tt_real_extreme",
    "ft",
    "ft_time",
    "ft_price",
    "ft_structural_time",
    "fail_reason",
    "fail_time",
    "fail_price",
    "structural_valid",
    "operational_valid",
    "operational_rejection_reason",
    "post_tt",
    "parent_tt_id",
    "generation",
    "labels",
]

PATTERN_FIELDS = [
    "pattern_id",
    "type",
    "status",
    "final_status",
    "direction",
    "origin_time",
    "origin_price",
    "end_time",
    "end_price",
    "size",
    "reading_id",
    "cycle_id",
    "detail",
]

AUDIT_FIELDS = [
    "sequence_id",
    "time",
    "price",
    "bar_time",
    "gap",
    "local_direction",
    "structural_origin",
    "structural_extreme",
    "excursion",
    "owner_reading_id",
    "owner_source",
    "owner_created_time",
    "owner_known_at_seq",
    "ownership_count",
    "functional_coverage",
    "active_readings",
    "inherited_readings",
    "local_readings",
    "functions_before",
    "functions_after",
    "events_emitted",
    "readings_created",
    "patterns_updated",
    "decision_reason",
]

NARRATIVE_FIELDS = [
    "bar_time",
    "open",
    "high",
    "low",
    "close",
    "gap",
    "extreme_order",
    "functions",
    "readings_started",
    "readings_closed",
    "active_at_close",
    "patterns",
    "pending",
]


def _price_fields(row: dict, fields: Iterable[str]) -> dict:
    out = {}
    for key in fields:
        value = row.get(key, "")
        if key in {
            "price",
            "knowledge_price",
            "module_origin",
            "module_extreme",
            "module_size",
            "structural_origin",
            "structural_extreme",
            "excursion",
            "a_origin",
            "a_end",
            "a_size",
            "b_origin",
            "b_extreme",
            "b_size",
            "c_origin",
            "c_extreme",
            "c_size",
            "tt_target",
            "tt_100",
            "tt_real_extreme",
            "x",
            "a",
            "b",
            "c",
            "aut_price",
            "tt_100_price",
            "ft_price",
            "fail_price",
            "gap",
            "origin_price",
            "end_price",
            "size",
            "open",
            "high",
            "low",
            "close",
        }:
            out[key] = price_s(int(value)) if value not in ("", None) else ""
        else:
            out[key] = value
    return out


def write_outputs(engine: Engine, out_dir: Path | str, stem: str = "v075") -> list[Path]:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "events": out_dir / f"{stem}_Eventos.csv",
        "readings": out_dir / f"{stem}_Lecturas.csv",
        "patterns": out_dir / f"{stem}_Patrones.csv",
        "audit": out_dir / f"{stem}_FunctionalAudit.csv",
        "narrative": out_dir / f"{stem}_BarNarrative.csv",
        "info": out_dir / f"{stem}_Informe.json",
        "comparison": out_dir / f"{stem}_Comparacion_1652_1700.csv",
    }
    with paths["events"].open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=EVENT_FIELDS)
        writer.writeheader()
        for row in engine.events:
            writer.writerow(_price_fields(row, EVENT_FIELDS))
    with paths["readings"].open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=READING_FIELDS)
        writer.writeheader()
        for r in sorted(engine.readings, key=lambda item: (item.created_time, item.reading_id)):
            row = {
                "reading_id": r.reading_id,
                "direction": "UP" if r.direction > 0 else "DOWN",
                "state": r.state,
                "created_time": ms_to_text(r.created_time),
                "created_seq": r.created_seq,
                "created_bar": ms_to_hms(r.created_bar * 60000)[:5],
                "closed_time": ms_to_text(r.closed_time) if r.closed_time else "",
                "parent_reading_id": r.parent_reading_id,
                "origin_reason": r.origin_reason,
                "module_origin": r.module_origin,
                "module_extreme": r.module_extreme,
                "x": r.module_size,
                "a_origin": r.a_origin,
                "a_end": r.a_end,
                "a": r.a_size,
                "b_origin": r.b_origin,
                "b_extreme": r.b_extreme,
                "b": r.b_size,
                "c_origin": r.c_origin,
                "c_extreme": r.c_extreme,
                "c": r.c_size,
                "aut_time": ms_to_text(r.aut_time) if r.aut_time else "",
                "aut_price": r.aut_price,
                "tt_target": r.tt_target,
                "tt_100_time": ms_to_text(r.tt_time) if r.tt_time else "",
                "tt_100_price": r.tt_price,
                "tt_confirmation_time": ms_to_text(r.tt_confirmation_time) if r.tt_confirmation_time else "",
                "tt_knowledge_time": ms_to_text(r.tt_knowledge_time) if r.tt_knowledge_time else "",
                "tt_real_extreme": r.tt_extreme,
                "ft": int(r.ft),
                "ft_time": ms_to_text(r.ft_time) if r.ft_time else "",
                "ft_price": r.ft_price,
                "ft_structural_time": ms_to_text(r.ft_structural_time) if r.ft_structural_time else "",
                "fail_reason": r.fail_reason,
                "fail_time": ms_to_text(r.fail_time) if r.fail_time else "",
                "fail_price": r.fail_price,
                "structural_valid": int(r.structural_valid),
                "operational_valid": int(r.operational_valid),
                "operational_rejection_reason": r.operational_rejection_reason,
                "post_tt": int(r.post_tt),
                "parent_tt_id": r.parent_tt_id,
                "generation": r.generation,
                "labels": ";".join(f"{idx}:{label}" for idx, label in r.labels),
            }
            writer.writerow(_price_fields(row, READING_FIELDS))
    with paths["patterns"].open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=PATTERN_FIELDS)
        writer.writeheader()
        for row in engine.patterns:
            writer.writerow(_price_fields(row, PATTERN_FIELDS))
    with paths["audit"].open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=AUDIT_FIELDS)
        writer.writeheader()
        for row in engine.audit:
            writer.writerow(_price_fields(row, AUDIT_FIELDS))
    with paths["narrative"].open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=NARRATIVE_FIELDS)
        writer.writeheader()
        for row in engine.narrative:
            writer.writerow(_price_fields(row, NARRATIVE_FIELDS))
    info = {
        "version": VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "feed_points": len(engine.points),
        "bars": len(engine.bars),
        "movements": len(engine.movements),
        "readings": len(engine.readings),
        "events": len(engine.events),
        "patterns": len(engine.patterns),
        "active_readings": len(engine.active),
        "AFS2_READY": bool(engine.afs2.get("AFS2_READY", False)),
        "causality": {
            "event_count": len(engine.events),
            "all_knowledge_after_structural": all(
                event["knowledge_time_ms"] >= event["structural_time_ms"] for event in engine.events
            ),
            "all_knowledge_after_confirmation": all(
                event["knowledge_time_ms"] >= event["confirmation_time_ms"] for event in engine.events
            ),
            "event_ids_append_only": [e["event_id"] for e in engine.events]
            == [f"E{index:06d}" for index in range(1, len(engine.events) + 1)],
            "sequence_ids_real_feed": all(
                event["sequence_id"] == event["knowledge_sequence_id"]
                for event in engine.events
            ),
            "tt_requires_b_grande": all(
                (not r.tt_hit) or (r.b_grande_time and r.tt_knowledge_time >= r.b_grande_time)
                for r in engine.readings
            ),
        },
        "AFS2": engine.afs2,
        "coverage": {
            k: v
            for k, v in engine.coverage.items()
            if k not in ("geometric_uncovered", "functional_uncovered")
        },
        "coverage_uncovered_samples": {
            "geometric": engine.coverage.get("geometric_uncovered", [])[:10],
            "functional": engine.coverage.get("functional_uncovered", [])[:10],
        },
        "pending": engine.pending,
        "implementation_pending": [
            "post_tt_fallido",
            "ft_expiration_semantics",
            "late_ft_entry_semantics",
            "A>module_guard_is_provisional_2x",
            "macro_stream_40_points_not_separate_scale",
            "owner_coverage_partial_is_informative",
        ],
        "constants": {
            "MOVE": MOVE,
            "STRUCTURAL_MOVE": STRUCTURAL_MOVE,
            "RETRACE_NUM": RETRACE_NUM,
            "RETRACE_DEN": RETRACE_DEN,
            "MIN_MODULE": MIN_MODULE,
            "A_MAX_MODULE_MULTIPLE": A_MAX_MODULE_MULTIPLE,
            "MAX_ACTIVE": MAX_ACTIVE,
            "CUT_BUFFER": CUT_BUFFER,
            "A_SIGNIFICANT_NUM": A_SIGNIFICANT_NUM,
            "A_SIGNIFICANT_DEN": A_SIGNIFICANT_DEN,
        },
    }
    paths["info"].write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
    comparison_rows = []
    window_start = parse_hms(WINDOW_START, engine.start_time)
    window_end = parse_hms(WINDOW_END, engine.start_time)
    for r in engine.readings:
        if window_start <= r.created_time <= window_end:
            comparison_rows.append(
                {
                    "reading_id": r.reading_id,
                    "module_origin": r.module_origin,
                    "module_extreme": r.module_extreme,
                    "module_size": r.module_size,
                    "a_end": r.a_end,
                    "b_extreme": r.b_extreme,
                    "tt_target": r.tt_target,
                    "tt_hit": int(r.tt_hit),
                    "ft": int(r.ft),
                    "state": r.state,
                    "origin_reason": r.origin_reason,
                }
            )
    with paths["comparison"].open("w", newline="", encoding="utf-8-sig") as fh:
        fields = [
            "reading_id",
            "module_origin",
            "module_extreme",
            "module_size",
            "a_end",
            "b_extreme",
            "tt_target",
            "tt_hit",
            "ft",
            "state",
            "origin_reason",
        ]
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in comparison_rows:
            writer.writerow(_price_fields(row, fields))
    return list(paths.values())


PREFIX_EVENT_FIELDS = [
    "event_id",
    "sequence_id",
    "knowledge_sequence_id",
    "structural_sequence_id",
    "confirmation_sequence_id",
    "time_ms",
    "structural_time_ms",
    "confirmation_time_ms",
    "kind",
    "function",
    "new_state",
    "reading_id",
    "parent_reading_id",
    "price",
    "module_origin",
    "module_extreme",
    "a_origin",
    "a_end",
    "b_origin",
    "b_extreme",
    "c_origin",
    "c_extreme",
    "tt_target",
    "tt_100",
    "ft",
    "reason",
]


def _prefix_events(engine: Engine, cutoff: int) -> list[dict]:
    return [
        event
        for event in engine.events
        if event["knowledge_time_ms"] <= cutoff and event["kind"] != "FIN_FEED"
    ]


def compare_prefix(full: Engine, prefix: Engine, cutoff: int) -> dict:
    full_events = _prefix_events(full, cutoff)
    prefix_events = _prefix_events(prefix, cutoff)
    mismatch = None
    limit = min(len(full_events), len(prefix_events))
    for index in range(limit):
        left = tuple(full_events[index][field] for field in PREFIX_EVENT_FIELDS)
        right = tuple(prefix_events[index][field] for field in PREFIX_EVENT_FIELDS)
        if left != right:
            mismatch = {
                "index": index,
                "full": full_events[index],
                "prefix": prefix_events[index],
                "fields": [
                    field
                    for field in PREFIX_EVENT_FIELDS
                    if full_events[index][field] != prefix_events[index][field]
                ],
            }
            break
    if mismatch is None and len(full_events) != len(prefix_events):
        index = limit
        mismatch = {
            "index": index,
            "full": full_events[index] if index < len(full_events) else None,
            "prefix": prefix_events[index] if index < len(prefix_events) else None,
            "fields": ["event_count"],
        }
    return {
        "cutoff_time": ms_to_text(cutoff),
        "cutoff_ms": cutoff,
        "full_events": len(full_events),
        "prefix_events": len(prefix_events),
        "full_readings": len(full.readings),
        "prefix_readings": len(prefix.readings),
        "pass": mismatch is None,
        "mismatch": mismatch,
    }


def run_prefix_matrix(
    points: list[Pt],
    bars: dict[int, Bar],
    cutoffs: list[int],
    full: Engine | None = None,
) -> tuple[Engine, list[dict]]:
    full = full or run_engine(points, bars)
    rows: list[dict] = []
    for cutoff in sorted(set(cutoffs)):
        prefix_points = [p for p in points if p.time_ms <= cutoff]
        if not prefix_points:
            continue
        prefix = run_engine(prefix_points, bars)
        row = compare_prefix(full, prefix, cutoff)
        rows.append(row)
    failures = sum(1 for row in rows if not row["pass"])
    full.afs2 = evaluate_afs2(full, prefix_failures=failures)
    return full, rows


def evaluate_afs2(engine: Engine, prefix_failures: int | None = None) -> dict:
    expected_ids = [f"E{index:06d}" for index in range(1, len(engine.events) + 1)]
    event_ids = [event["event_id"] for event in engine.events]
    event_append_only = event_ids == expected_ids
    feed_sequences = [p.seq for p in engine.points]
    sequence_ids = [event["sequence_id"] for event in engine.events]
    sequence_real = (
        all(event["sequence_id"] == event["knowledge_sequence_id"] for event in engine.events)
        and all(event["sequence_id"] in set(feed_sequences) for event in engine.events)
        and sequence_ids == sorted(sequence_ids)
    )
    knowledge_valid = all(
        event["knowledge_time_ms"] >= event["confirmation_time_ms"]
        and event["knowledge_time_ms"] >= event["structural_time_ms"]
        for event in engine.events
    )
    tt_after_b = all(
        (not r.tt_hit)
        or (
            r.b_grande_time
            and r.tt_knowledge_time
            and r.tt_knowledge_time >= r.b_grande_time
            and r.b_size >= r.a_size
        )
        for r in engine.readings
    )
    tt_targets_valid = all(
        (not r.tt_hit) or r.tt_target == r.a_end + r.direction * r.module_size
        for r in engine.readings
    )
    gap_first = True
    event_by_seq: dict[int, list[dict]] = defaultdict(list)
    for event in engine.events:
        event_by_seq[event["sequence_id"]].append(event)
    for bar_idx in sorted({p.bar for p in engine.points}):
        bar = engine.bars.get(bar_idx)
        if bar is None or not bar.gap:
            continue
        first = next((p for p in engine.points if p.bar == bar_idx), None)
        if first is None:
            continue
        events = event_by_seq.get(first.seq, [])
        if not events or events[0]["kind"] != "GAP":
            gap_first = False
            break
    geometry_generic = any(r.tt_hit and r.ft for r in engine.readings) and tt_targets_valid
    coverage = engine.coverage
    owner_sources = {"C", "B", "A", "MODULE", "NOISE", "NONE"}
    owner_audit_complete = (
        len(engine.knowledge_audit) == len(engine.points)
        and all(
            row["owner_source"] in owner_sources
            and row["functional_coverage"] in {"OK", "UNCOVERED"}
            and (not row["owner_reading_id"] or row["owner_known_at_seq"] <= row["sequence_id"])
            for row in engine.knowledge_audit
        )
    )
    causal_counts_valid = (
        coverage.get("causal_geometric_count", 0) <= coverage.get("geometric_count", 0)
        and coverage.get("causal_functional_count", 0) <= coverage.get("functional_count", 0)
        and coverage.get("causal_functional_movement_count", 0) <= coverage.get("movement_count", 0)
    )
    forbidden = FORBIDDEN_FUNCTIONS & {event["function"] for event in engine.events}
    prefix_ok = None if prefix_failures is None else prefix_failures == 0
    checks = {
        "prefix_failures": prefix_failures,
        "prefix_ok": prefix_ok,
        "event_id_append_only": event_append_only,
        "sequence_id_real_feed": sequence_real,
        "knowledge_time_valid": knowledge_valid,
        "tt_after_b_grande": tt_after_b,
        "tt_target_formula": tt_targets_valid,
        "gap_before_other_branches": gap_first,
        "geometry_invariants": geometry_generic,
        "owner_audit_complete": owner_audit_complete,
        "causal_counts_valid": causal_counts_valid,
        "vocabulary_clean": not forbidden,
    }
    ready = all(
        value is True
        for key, value in checks.items()
        if key not in {"prefix_failures"}
    ) and prefix_ok is True
    return {
        "AFS2_READY": ready,
        "AFS2_SCOPE": "integridad causal y prefijos; no implica cobertura funcional total",
        "checks": checks,
        "coverage": {
            "owner_coverage_ok": bool(coverage.get("owner_coverage_ok", False)),
            "owner_tick_count": coverage.get("owner_tick_count", 0),
            "uncovered_tick_count": coverage.get("uncovered_tick_count", 0),
            "causal_geometric_ok": bool(coverage.get("causal_geometric_ok", False)),
            "causal_functional_ok": bool(coverage.get("causal_functional_ok", False)),
            "causal_geometric_count": coverage.get("causal_geometric_count", 0),
            "causal_functional_count": coverage.get("causal_functional_count", 0),
            "geometric_count": coverage.get("geometric_count", 0),
            "functional_count": coverage.get("functional_count", 0),
        },
        "unresolved_rules": list(engine.pending),
        "unresolved_blocking": [],
    }


def run_engine(points: list[Pt], bars: dict[int, Bar]) -> Engine:
    return Engine(points, bars).run()


def _synthetic_engine(prices: list[float], start_ms: int) -> Engine:
    points = [Pt(price_i(p), i + 1, start_ms + i * 1000, (start_ms + i * 1000) // 60000) for i, p in enumerate(prices)]
    bars: dict[int, Bar] = {}
    for p in points:
        bar = bars.get(p.bar)
        if bar is None:
            prev = bars[max(bars)].last.price if bars else None
            gap = p.price - prev if prev is not None else 0
            bars[p.bar] = Bar(p.bar, ms_to_hms(p.bar * 60000)[:5], p, p, p, p, prev, gap)
        else:
            if p.price > bar.high.price:
                bar.high = p
            if p.price < bar.low.price:
                bar.low = p
            bar.last = p
    return run_engine(points, bars)


def selftest() -> None:
    base = 1_792_169_100_000
    engine = _synthetic_engine([100.00, 94.00, 100.00, 94.00, 100.00, 94.00, 100.00], base)
    assert engine.readings
    assert any(r.tt_hit for r in engine.readings)
    assert any(r.ft for r in engine.readings)
    assert len(engine.audit) == 7
    assert len(engine.narrative) >= 1
    assert engine.coverage["movement_count"] > 0
    assert not (FORBIDDEN_FUNCTIONS & {e["function"] for e in engine.events})
    with tempfile.TemporaryDirectory() as tmp:
        paths = write_outputs(engine, Path(tmp), "selftest")
        assert all(p.exists() for p in paths)
    print(f"SELFTEST OK v{VERSION}: 8 comprobaciones")


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=f"TM core v{VERSION} functional reader")
    parser.add_argument("--feed", type=Path)
    parser.add_argument("--out", type=Path, default=Path("out_v075"))
    parser.add_argument("--stem", default="v075")
    parser.add_argument("--start")
    parser.add_argument("--end")
    parser.add_argument("--window-start", default=WINDOW_START)
    parser.add_argument("--window-end", default=WINDOW_END)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args(argv)
    if args.selftest:
        selftest()
        return 0
    if args.feed is None:
        parser.error("--feed is required unless --selftest")
    points, bars = load_feed(args.feed)
    base = points[0].time_ms
    start = parse_hms(args.start, base) if args.start else None
    end = parse_hms(args.end, base) if args.end else None
    points = filter_points(points, start, end)
    engine = run_engine(points, bars)
    paths = write_outputs(engine, args.out, args.stem)
    print(f"v{VERSION} readings={len(engine.readings)} events={len(engine.events)} movements={len(engine.movements)}")
    print(f"coverage geometric={engine.coverage['geometric_ok']} functional={engine.coverage['functional_ok']}")
    print(f"outputs={args.out}")
    for path in paths:
        print(f"  {path.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
